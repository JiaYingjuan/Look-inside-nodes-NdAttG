import os
import sys
import gc
import argparse
import torch
from torch.optim import Adam
import pandas as pd
import dgl

from torch_geometric.datasets import ZINC
from torch_geometric.loader import DataLoader

sys.path.append(os.path.join(os.path.dirname(__file__), '..'))

from model.GT.graph_transformer_net import GraphTransformerNet
from model.GT.laplace_pos_enc import laplacian_positional_encoding


def pyg_to_dgl(data):
    """Converts a PyTorch Geometric (PyG) data object to a Deep Graph Library (DGL) graph object."""
    edge_index = data.edge_index
    src = edge_index[0].to('cpu')
    dst = edge_index[1].to('cpu')
    
    g = dgl.graph((src, dst))
    
    g.ndata['feat'] = data.x[:g.num_nodes(), :].to('cpu').float()
    g.edata['feat'] = data.edge_attr.float()
    
    num_existing_nodes = g.num_nodes()
    num_total_nodes = data.x.size(0)
    
    if num_total_nodes > num_existing_nodes:
        num_new_nodes = num_total_nodes - num_existing_nodes
        g.add_nodes(num_new_nodes)
        g.ndata['feat'][num_existing_nodes:] = data.x[num_existing_nodes:, :].to('cpu').float()
    return g


class EarlyStopper:
    """Early stopping utility to prevent overfitting"""
    
    def __init__(self, patience=1, min_delta=0):
        self.patience = patience
        self.min_delta = min_delta
        self.counter = 0
        self.min_validation_loss = float('inf')

    def early_stop(self, validation_loss):
        """Check if training should stop early"""
        if validation_loss < self.min_validation_loss:
            self.min_validation_loss = validation_loss
            self.counter = 0
        elif validation_loss >= (self.min_validation_loss + self.min_delta):
            self.counter += 1
            if self.counter >= self.patience:
                return True
        return False


# Argument parser configuration
parser = argparse.ArgumentParser()
parser.add_argument('--batch-size', type=int, default=128, help='Input batch size for training')
parser.add_argument('--epochs', type=int, default=300, help='Number of epochs to train')
parser.add_argument('--model', type=str, default='KAA_GT', help='Model to test')
parser.add_argument('--patience', type=int, default=20, help='Patience for early stopping')
parser.add_argument('--device_num', type=int, default=0, help='GPU device number')
parser.add_argument('--seed', type=int, default=1, help='Random seed')
parser.add_argument('--pos_enc_dim', type=int, default=2, help='Laplacian positional encoding dimension')
parser.add_argument('--hidden_dim', type=int, default=64, help='Hidden dimension size')
parser.add_argument('--layers', type=int, default=1, help='Number of layers')
parser.add_argument('--in_feat_dropout', type=float, default=0, help='Input feature dropout rate')
parser.add_argument('--dropout', type=float, default=0, help='Dropout rate')
parser.add_argument('--spline_order', type=int, default=0, help='Spline order for KAN layers')
parser.add_argument('--grid_size', type=int, default=0, help='Grid size for KAN layers')
parser.add_argument('--hidden_layers', type=int, default=0, help='Number of hidden layers')
parser.add_argument('--train_round', type=int, default=5, help='Number of training rounds')

args = parser.parse_args()

# Set random seed for reproducibility
random_seed = args.seed
torch.manual_seed(random_seed)
torch.cuda.manual_seed(random_seed)
torch.backends.cudnn.benchmark = False
torch.backends.cudnn.deterministic = True

# Device configuration
device = torch.device(f'cuda:{args.device_num}' if torch.cuda.is_available() else 'cpu')

# Load ZINC dataset
train_dataset = ZINC('./dataset/ZINC', subset=True, split='train')
val_dataset = ZINC('./dataset/ZINC', subset=True, split='val')
test_dataset = ZINC('./dataset/ZINC', subset=True, split='test')


def apply_lap_pos_enc(dataset, pos_enc_dim):
    """Applies Laplacian positional encoding to the entire dataset."""
    processed_data_list = []
    
    for data in dataset:
        temp_graph = pyg_to_dgl(data)
        temp_graph = laplacian_positional_encoding(temp_graph, pos_enc_dim)
        pos_enc = temp_graph.ndata['lap_pos_enc']
        
        # # Add shape check
        # num_nodes = temp_graph.num_nodes()
        # if pos_enc.shape != (num_nodes, pos_enc_dim):
        #     print(f"Warning: Positional encoding shape error! Expected ({num_nodes}, {pos_enc_dim}), got {pos_enc.shape}")
        #     print(f"Dataset: {data}, Number of nodes: {num_nodes}")
        # else:
        #     print(f"Positional encoding shape is correct!")
        
        data.lap_pos_enc = pos_enc
        processed_data_list.append(data)
    
    return processed_data_list


# Apply positional encoding to datasets
train_data_processed = apply_lap_pos_enc(train_dataset, args.pos_enc_dim)
val_data_processed = apply_lap_pos_enc(val_dataset, args.pos_enc_dim)
test_data_processed = apply_lap_pos_enc(test_dataset, args.pos_enc_dim)

# Create data loaders
train_loader = DataLoader(train_data_processed, args.batch_size, shuffle=True)
val_loader = DataLoader(val_data_processed, args.batch_size, shuffle=False)
test_loader = DataLoader(test_data_processed, args.batch_size, shuffle=False)

# Network parameters configuration
net_params = {
    'kind': args.model,
    'in_dim': train_dataset.num_features,
    'hidden_dim': args.hidden_dim,
    'out_dim': args.hidden_dim,
    'n_heads': 1,
    'in_feat_dropout': args.in_feat_dropout,
    'dropout': args.dropout,
    'pos_enc_dim': args.pos_enc_dim,
    'L': args.layers,
    'layer_norm': False,
    'batch_norm': True,
    'residual': True,
    'device': device,
    'lap_pos_enc': True,
    'wl_pos_enc': False,
    'spline_order': args.spline_order,
    'grid_size': args.grid_size,
    'hidden_layers': args.hidden_layers,
    'batch_size': args.batch_size,
    'n_classes': 1,
    'edge_feat': False,
    'num_atom_type': 1,
    'num_bond_type': torch.unique(train_dataset.edge_attr, dim=0).size(0)
}


# Training loop
val_maes = []
test_maes = []

for run in range(args.train_round):
    print()
    print(f'Run {run}:')
    print()
    
    # Clean up memory
    gc.collect()
    
    # Initialize model
    model = GraphTransformerNet(net_params).to(net_params['device'])
    total_params = sum(p.numel() for p in model.parameters())
    print('Number of parameters:', total_params)
    print()
    
    optimizer = Adam(model.parameters(), lr=0.001)


    def train(epoch):
        """Training function for one epoch"""
        model.train()

        total_loss = 0
        for i, data in enumerate(train_loader):
            graph = pyg_to_dgl(data)
            graph = graph.to(device)
            data = data.to(device)
            
            # # Debug information
            # print(f"Batch {i+1}:")
            # print(f"  Number of nodes: {graph.num_nodes()}")
            # print(f"  Original positional encoding shape: {data.lap_pos_enc.shape}")

            # # Ensure positional encoding maintains correct shape
            # if data.lap_pos_enc.dim() == 1:
            #     data.lap_pos_enc = data.lap_pos_enc.view(-1, args.pos_enc_dim)

            # print(f"  Processed positional encoding shape: {data.lap_pos_enc.shape}")
            
            optimizer.zero_grad()
            out = model(graph, graph.ndata['feat'].float(), graph.edata['feat'].float(), data.batch, data.lap_pos_enc)
            loss = (out.squeeze() - data.y).abs().mean()
            loss.backward()
            total_loss += loss.item() * data.num_graphs
            optimizer.step()
        return total_loss / len(train_loader.dataset)


    @torch.no_grad()
    def test(loader):
        """Testing function"""
        model.eval()

        total_error = 0
        for data in loader:
            graph = pyg_to_dgl(data)
            graph = graph.to(device)
            data = data.to(device)
            out = model(graph, graph.ndata['feat'].float(), graph.edata['feat'].float(), data.batch, data.lap_pos_enc)
            total_error += (out.squeeze() - data.y).abs().sum().item()
        return total_error / len(loader.dataset)


    best_val_mae = test_mae = float('inf')
    early_stopper = EarlyStopper(patience=args.patience)
    
    for epoch in range(1, args.epochs + 1):
        loss = train(epoch)
        val_mae = test(val_loader)

        if val_mae < best_val_mae:
            best_val_mae = val_mae
            test_mae = test(test_loader)
            print(f'Epoch: {epoch:03d}, Loss: {loss:.4f}, '
                  f'Val: {val_mae:.4f}, Test: {test_mae:.4f}')

        if early_stopper.early_stop(val_mae):
            print(f"Stopped at epoch {epoch}")
            break

    test_maes.append(test_mae)
    val_maes.append(best_val_mae)

# Calculate final results
test_mae = torch.tensor(test_maes)
print('===========================')
print(f'Final Test: {test_mae.mean():.4f} ± {test_mae.std():.4f}')

# Save results
with open('zinc_results.txt', 'a') as f: 
    f.write(f"Model:{args.model}, MAE:{test_mae.mean():.4f}±{test_mae.std():.4f}\n")
    
print("Results have been saved to zinc_results.txt")