import torch
import torch.nn as nn
import torch.nn.functional as F
from torch_geometric.nn import MessagePassing
from torch_geometric.utils import add_self_loops, remove_self_loops, softmax

class HeteGATConv(MessagePassing):
    def __init__(self, in_channels, out_channels, heads=1, concat=True,
                 negative_slope=0.2, dropout=0.0, bias=True, residual=False, **kwargs):
        kwargs.setdefault('aggr', 'add')
        super().__init__(node_dim=0, **kwargs)
        
        self.in_channels = in_channels
        self.out_channels = out_channels
        self.heads = heads
        self.concat = concat
        self.negative_slope = negative_slope
        self.dropout = dropout
        self.residual = residual
        
        # Linear transformation parameters
        self.lin_src = nn.Linear(in_channels, heads * out_channels, bias=False)
        self.lin_dst = nn.Linear(in_channels, heads * out_channels, bias=False)
        
        # Attention parameters
        self.att_src = nn.Parameter(torch.Tensor(1, heads, out_channels))
        self.att_dst = nn.Parameter(torch.Tensor(1, heads, out_channels))
        
        # Residual connection
        if residual:
            self.res_linear = nn.Linear(in_channels, heads * out_channels, bias=False)
        else:
            self.register_parameter('res_linear', None)
            
        # Bias term
        if bias:
            self.bias = nn.Parameter(torch.Tensor(heads * out_channels))
        else:
            self.register_parameter('bias', None)
            
        self.reset_parameters()

    def reset_parameters(self):
        nn.init.xavier_uniform_(self.lin_src.weight)
        nn.init.xavier_uniform_(self.lin_dst.weight)
        nn.init.xavier_uniform_(self.att_src)
        nn.init.xavier_uniform_(self.att_dst)
        if self.res_linear is not None:
            nn.init.xavier_uniform_(self.res_linear.weight)
        if self.bias is not None:
            nn.init.zeros_(self.bias)

    def forward(self, x, edge_index, size=None, return_attention_weights=False):
        # Feature transformation
        x_src = self.lin_src(x).view(-1, self.heads, self.out_channels)
        x_dst = self.lin_dst(x).view(-1, self.heads, self.out_channels)
        
        # Add self-loops
        edge_index, _ = remove_self_loops(edge_index)
        edge_index, _ = add_self_loops(edge_index, num_nodes=x.size(0))
        
        # Propagate messages
        out = self.propagate(edge_index, x=(x_src, x_dst), size=size)
        
        # Process output
        if self.concat:
            out = out.view(-1, self.heads * self.out_channels)
        else:
            out = out.mean(dim=1)
            
        # Residual connection
        if self.res_linear is not None:
            res = self.res_linear(x)
            out += res
            
        if self.bias is not None:
            out += self.bias
            
        if return_attention_weights:
            return out, self._alpha
        return out

    def message(self, edge_index_i, x_i, x_j, size_i):
        # Calculate attention scores
        x_i = x_i.view(-1, self.heads, self.out_channels)
        x_j = x_j.view(-1, self.heads, self.out_channels)
        
        # Fix: Correctly calculate attention scores
        alpha = (x_i * self.att_src).sum(dim=-1) + (x_j * self.att_dst).sum(dim=-1)
        alpha = F.leaky_relu(alpha, self.negative_slope)
        
        # Fix: Correctly call softmax
        alpha = softmax(alpha, index=edge_index_i, num_nodes=size_i)  # Use num_nodes parameter
        
        # Save attention weights
        self._alpha = alpha
        
        # Apply dropout
        alpha = F.dropout(alpha, p=self.dropout, training=self.training)
        
        return x_j * alpha.view(-1, self.heads, 1)

class RelationAggregator(nn.Module):
    def __init__(self, in_channels, att_size=128):
        super().__init__()
        self.att_linear = nn.Linear(in_channels, att_size)
        self.att_query = nn.Linear(att_size, 1, bias=False)
        self.reset_parameters()

    def reset_parameters(self):
        nn.init.xavier_uniform_(self.att_linear.weight)
        nn.init.zeros_(self.att_linear.bias)
        nn.init.xavier_uniform_(self.att_query.weight)

    def forward(self, embeddings, return_attention=False):
        # embeddings: [num_nodes, num_relations, in_channels]
        # Calculate attention weights
        v = torch.tanh(self.att_linear(embeddings))  # [N, R, att_size]
        e = self.att_query(v)  # [N, R, 1]
        alpha = F.softmax(e, dim=1)  # [N, R, 1]
        
        # Weighted aggregation
        out = torch.sum(embeddings * alpha, dim=1)  # [N, in_channels]
        
        if return_attention:
            return out, alpha.squeeze(-1)
        return out