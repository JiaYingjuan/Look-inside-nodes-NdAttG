import os
import sys
import torch
import argparse
from torch_geometric.datasets import Planetoid
import numpy as np
import torch_geometric.transforms as T
import torch.nn.functional as F
from torch import nn
import time
from thop import profile, clever_format
from torch_geometric.nn.conv import MessagePassing

# Get the absolute path of the current file
current_dir = os.path.dirname(os.path.abspath(__file__))
project_root = os.path.dirname(os.path.dirname(os.path.dirname(current_dir)))
sys.path.insert(0, project_root)
from model.HAN.HeteGAT import HeteGAT  # Import HeteGAT model
from model.HAN.HeteGAT_LPAT import HeteGAT_LPAT  # Import HeteGAT model

parser = argparse.ArgumentParser(description='PyTorch implementation of HeteGAT training.')

# HeteGAT specific parameters
parser.add_argument('--model', type=str, default='HeteGAT', help='the used model type')
parser.add_argument('--hidden_dim', type=int, default=8, help='the hidden dimension')
parser.add_argument('--heads', type=int, default=8, help='the head number')
parser.add_argument('--num_layer', type=int, default=2, help='the model layer number')
parser.add_argument('--att_size', type=int, default=128, help='relation attention size')

parser.add_argument('--device_num', type=int, default=0, help='the device number')
parser.add_argument('--epoch_num', type=int, default=300, help='the epoch number')
parser.add_argument('--lr', type=float, default=0.005, help='the learning rate')
parser.add_argument('--drop_rate', type=float, default=0.3, help='the dropping rate')

parser.add_argument('--seed', type=int, default=1, help='the random seed')
parser.add_argument('--dataset', type=str, default='Cora', help='the test dataset')
parser.add_argument('--train_round', type=int, default=10, help='the train round number')
parser.add_argument('--file_id', type=int, default=0, help='the file id')

# Multi-relation settings
parser.add_argument('--num_relations', type=int, default=3, help='number of relations in the graph')

args = parser.parse_args()

# Random seed settings
random_seed = args.seed
torch.manual_seed(random_seed)
if torch.cuda.is_available():
    torch.cuda.manual_seed(random_seed)
    torch.cuda.manual_seed_all(random_seed)
torch.backends.cudnn.benchmark = False
torch.backends.cudnn.deterministic = True

# Device selection
device = torch.device(f'cuda:{args.device_num}' if torch.cuda.is_available() else 'cpu')

# Load dataset
dataset = Planetoid(root="./dataset/", name=args.dataset, transform=T.NormalizeFeatures())
data = dataset[0].to(device=device)

# Build multi-relation graph data
def build_heterogeneous_relations(data, num_relations=3):
    edge_index = data.edge_index
    num_nodes = data.num_nodes
    
    relation_edge_indices = []
    
    # Relation 1: Original relation
    relation_edge_indices.append(edge_index)
    
    # Relation 2: Reverse relation
    reverse_edge_index = torch.stack([edge_index[1], edge_index[0]], dim=0)
    relation_edge_indices.append(reverse_edge_index)
    
    # Relation 3: Self-loop relation
    self_loop = torch.arange(num_nodes).repeat(2, 1).to(edge_index.device)
    relation_edge_indices.append(self_loop)
    
    # If more relations are needed, generate randomly
    for i in range(3, num_relations):
        num_edges = edge_index.size(1)
        sample_size = int(num_edges * 0.7)
        indices = torch.randperm(num_edges)[:sample_size]
        sampled_edges = edge_index[:, indices]
        relation_edge_indices.append(sampled_edges)
    
    return relation_edge_indices

# Build multi-relation data
relation_edge_indices = build_heterogeneous_relations(data, args.num_relations)

if args.model == 'HeteGAT':
    # Initialize HeteGAT model
    model = HeteGAT(
        in_channels=dataset.num_features,
        hidden_channels=args.hidden_dim,
        out_channels=dataset.num_classes,
        heads=args.heads,
        num_relations=args.num_relations,
        num_layers=args.num_layer,
        att_size=args.att_size,
        dropout=args.drop_rate,
        residual=True,
        return_attention=False
    ).to(device)
elif args.model == 'HeteGAT_LPAT':
    # Initialize HeteGAT_LPAT model
    model = HeteGAT_LPAT(
        in_channels=dataset.num_features,
        hidden_channels=args.hidden_dim,
        out_channels=dataset.num_classes,
        heads=args.heads,
        num_relations=args.num_relations,
        num_layers=args.num_layer,
        att_size=args.att_size,
        dropout=args.drop_rate,
        residual=True,
        return_attention=False,
        omega_init=1.0,
        lambda_init=5.0
    ).to(device)

# Optimizer
optimizer = torch.optim.Adam(model.parameters(), lr=args.lr, weight_decay=0.0005)

# Calculate FLOPs and parameter count
def get_flops(model, x, relation_edge_indices):
    """Get FLOPs and parameter count for HeteGAT model"""
    # Count parameter quantity
    total_params = sum(p.numel() for p in model.parameters() if p.requires_grad)
    
    # Manual FLOPs estimation (avoid issues with thop.profile)
    num_nodes = x.size(0)
    num_edges = sum(edge_index.size(1) for edge_index in relation_edge_indices)
    
    flops = 0
    in_dim = x.size(1)
    hidden_dim = args.hidden_dim
    heads = args.heads
    num_layers = args.num_layer
    num_relations = args.num_relations
    att_size = args.att_size
    
    # Input transformation
    flops += num_nodes * in_dim * hidden_dim * heads
    
    # GAT layer computation
    for i in range(num_layers):
        # Computation for each relation per layer
        flops += num_relations * num_edges * hidden_dim * heads
        
        # If not the last layer, perform relation aggregation
        if i < num_layers - 1:
            flops += num_nodes * num_relations * hidden_dim * heads * att_size
            flops += num_nodes * num_relations * att_size  # Attention computation
    
    # Output layer
    flops += num_nodes * hidden_dim * heads * dataset.num_classes
    
    return flops, total_params

# Call after model initialization
sample_x = data.x.to(device).float()
total_flops, total_params = get_flops(model, sample_x, relation_edge_indices)
flops_m, params_m = clever_format([total_flops, total_params], "%.3f")

def train():
    """Training function"""
    model.train()
    optimizer.zero_grad()
    out = model(data.x, relation_edge_indices)
    loss = F.cross_entropy(out[data.train_mask], data.y[data.train_mask])
    loss.backward()
    print(f'Train loss: {loss.item():.4f}')
    optimizer.step()
    return loss.item()

@torch.no_grad()
def test():
    """Testing function"""
    model.eval()
    out = model(data.x, relation_edge_indices)
    _, pred = out.max(dim=1)
    
    # Calculate accuracy for each mask
    def calculate_accuracy(mask):
        correct = pred[mask].eq(data.y[mask]).sum().item()
        total = mask.sum().item()
        return correct / total if total > 0 else 0.0
    
    train_acc = calculate_accuracy(data.train_mask)
    val_acc = calculate_accuracy(data.val_mask)
    test_acc = calculate_accuracy(data.test_mask)
    
    return train_acc, val_acc, test_acc

# Training loop
test_acc_list = []
time_list = []
loss_list = []

for round in range(args.train_round):
    # Reset random seed
    torch.manual_seed(args.seed + round)
    if torch.cuda.is_available():
        torch.cuda.manual_seed_all(args.seed + round)
    
    print(f'Starting training round {round+1}/{args.train_round}')
    start_time = time.time()
    
    # Reset model parameters
    model.reset_parameters()
    
    best_val_acc = 0
    best_test_acc = 0
    
    # Training loop
    for epoch in range(args.epoch_num):
        epoch_start = time.time()
        
        # Training
        loss = train()
        loss_list.append(loss)
        
        # Testing
        train_acc, val_acc, test_acc = test()
        print(f'Epoch {epoch+1:03d}: Loss={loss:.4f}, '
              f'Train Acc={train_acc:.4f}, Val Acc={val_acc:.4f}, Test Acc={test_acc:.4f}')
        
        # Update best test accuracy
        if val_acc > best_val_acc:
            best_val_acc = val_acc
            best_test_acc = test_acc
        
        epoch_time = time.time() - epoch_start
        print(f'Epoch time: {epoch_time:.2f}s')
    
    # Record results for this round
    test_acc_list.append(best_test_acc)
    round_time = time.time() - start_time
    time_list.append(round_time)
    print(f'Round {round+1} completed. Best test acc: {best_test_acc:.4f}, Time: {round_time:.2f}s')

# Calculate average results
acc_avg = float(np.mean(test_acc_list))
acc_std = float(np.std(test_acc_list))
time_avg = float(np.mean(time_list))

print('\nTraining completed.')
print(f'Average test accuracy: {acc_avg:.4f} ± {acc_std:.4f}')
print(f'Average training time per round: {time_avg:.2f}s')

# Save results
result_str = (f"Model: {args.model}, Dataset: {args.dataset}, "
             f"Avg Acc: {acc_avg:.4f}±{acc_std:.4f}, "
             f"Time: {time_avg:.2f}s, "
             f"Params: {params_m}\n")

# Write results to file
with open('results.txt', 'a') as f:  # Use append mode
    f.write(result_str)

print("Results have been saved to results.txt")