import os
import sys
import gc
import argparse
import torch
import torch.nn as nn
import torch.nn.functional as F
import time
import numpy as np
import pandas as pd
from torch.optim import Adam
from torch_geometric.datasets import ZINC
from torch_geometric.loader import DataLoader
from torch_geometric.nn import global_add_pool
from torch_geometric.utils import degree
from thop import profile

# Get the absolute path of current file
current_dir = os.path.dirname(os.path.abspath(__file__))
project_root = os.path.dirname(os.path.dirname(os.path.dirname(current_dir)))
sys.path.insert(0, project_root)

from model.HLGAT_LPAT import HLGAT_LPAT  
from model.HLGAT import HLGAT  


class EarlyStopper:
    """Early stopping utility to prevent overfitting"""
    
    def __init__(self, patience=1, min_delta=0):
        self.patience = patience
        self.min_delta = min_delta
        self.counter = 0
        self.min_validation_loss = float('inf')

    def early_stop(self, validation_loss):
        """Check if training should stop early"""
        if validation_loss < self.min_validation_loss:
            self.min_validation_loss = validation_loss
            self.counter = 0
        elif validation_loss >= (self.min_validation_loss + self.min_delta):
            self.counter += 1
            if self.counter >= self.patience:
                return True
        return False


class HLGAT_ZINC_Model(nn.Module):
    """HLGAT Model for ZINC dataset regression task"""
    
    def __init__(self, gnn_layers, num_features, hidden_dim, n_targets, dropout, 
                 p_l=0.1, p_h=0.5, eps=0.8, embedding_layer=True):
        super(HLGAT_ZINC_Model, self).__init__()
        self.embedding_layer = embedding_layer
        
        # Node embedding layer
        if embedding_layer:
            self.node_emb = nn.Embedding(num_features, hidden_dim)
            input_dim = hidden_dim
        else:
            input_dim = num_features
        
        # Use complete HLGAT model - not just HLGATConv alone
        self.hlgat = HLGAT(
            in_channels=input_dim,
            hidden_dim=hidden_dim,
            out_channels=hidden_dim,  # Output dimension same as hidden dimension
            num_layers=gnn_layers,
            dropout=dropout,
            p_l=p_l,
            p_h=p_h,
            eps=eps
        )
        
        # Output layer
        self.mlp = nn.Sequential(
            nn.Linear(hidden_dim, hidden_dim // 2),
            nn.ReLU(),
            nn.Dropout(dropout),
            nn.Linear(hidden_dim // 2, n_targets)
        )
        self.dropout = nn.Dropout(dropout)
        
    def reset_parameters(self):
        """Reset model parameters"""
        self.hlgat.reset_parameters()
        for layer in self.mlp:
            if hasattr(layer, 'reset_parameters'):
                layer.reset_parameters()
    
    def forward(self, data):
        """Forward pass through the model"""
        x, edge_index, batch = data.x, data.edge_index, data.batch
        
        # Node embedding
        if self.embedding_layer:
            x = self.node_emb(x).squeeze()
        
        # Calculate degree normalization factor
        deg = degree(edge_index[0], num_nodes=x.size(0), dtype=x.dtype).clamp(min=1)
        norm = deg.pow(-0.5)
        
        # Pass through HLGAT model
        x = self.hlgat(x, edge_index, norm)
        x = self.dropout(x)
        
        # Global pooling and output
        x = global_add_pool(x, batch)
        return self.mlp(x)


class HLGAT_LPAT_ZINC_Model(nn.Module):
    """HLGAT LPAT Model for ZINC dataset regression task"""
    
    def __init__(self, gnn_layers, num_features, hidden_dim, n_targets, dropout, 
                 p_l=0.1, p_h=0.5, eps=0.8, embedding_layer=True, omega_init=1.0, lambda_init=5.0):
        super(HLGAT_LPAT_ZINC_Model, self).__init__()
        self.embedding_layer = embedding_layer
        
        # Node embedding layer
        if embedding_layer:
            self.node_emb = nn.Embedding(num_features, hidden_dim)
            input_dim = hidden_dim
        else:
            input_dim = num_features
        
        # Use complete HLGAT_LPAT model - not just HLGATConv alone
        self.hlgat_LPAT = HLGAT_LPAT(
            in_channels=input_dim,
            hidden_dim=hidden_dim,
            out_channels=hidden_dim,  # Output dimension same as hidden dimension
            num_layers=gnn_layers,
            dropout=dropout,
            p_l=p_l,
            p_h=p_h,
            eps=eps,
            omega_init=omega_init,
            lambda_init=lambda_init
        )
        
        # Output layer
        self.mlp = nn.Sequential(
            nn.Linear(hidden_dim, hidden_dim // 2),
            nn.ReLU(),
            nn.Dropout(dropout),
            nn.Linear(hidden_dim // 2, n_targets)
        )
        self.dropout = nn.Dropout(dropout)
        
    def reset_parameters(self):
        """Reset model parameters"""
        self.hlgat_LPAT.reset_parameters()
        for layer in self.mlp:
            if hasattr(layer, 'reset_parameters'):
                layer.reset_parameters()
    
    def forward(self, data):
        """Forward pass through the model"""
        x, edge_index, batch = data.x, data.edge_index, data.batch
        
        # Node embedding
        if self.embedding_layer:
            x = self.node_emb(x).squeeze()
        
        # Calculate degree normalization factor
        deg = degree(edge_index[0], num_nodes=x.size(0), dtype=x.dtype).clamp(min=1)
        norm = deg.pow(-0.5)
        
        # Pass through HLGAT_LPAT model
        x = self.hlgat_LPAT(x, edge_index, norm)
        x = self.dropout(x)
        
        # Global pooling and output
        x = global_add_pool(x, batch)
        return self.mlp(x)


def get_model_info(model, data):
    """Function to get model FLOPs and parameter count"""
    total_params = sum(p.numel() for p in model.parameters())
    
    # Use thop for FLOPs estimation
    with torch.no_grad():
        model.eval()
        flops, _ = profile(model, inputs=(data,), verbose=False)
    
    return flops, total_params


# Argument parser configuration
parser = argparse.ArgumentParser(description='HLGAT for ZINC Regression')

# HLGAT specific parameters
parser.add_argument('--model', type=str, default='HLGAT_LPAT', help='Model type to use')
parser.add_argument('--hidden_dim', type=int, default=256, help='Hidden dimension size')
parser.add_argument('--gnn_layers', type=int, default=2, help='Number of HLGAT layers')
parser.add_argument('--p_l', type=float, default=0.1, help='Leak coefficient for low-pass filter')
parser.add_argument('--p_h', type=float, default=0.5, help='Leak coefficient for high-pass filter')
parser.add_argument('--eps', type=float, default=0.8, help='Residual connection weight')

# General training parameters
parser.add_argument('--batch_size', type=int, default=128, help='Input batch size')
parser.add_argument('--epochs', type=int, default=300, help='Number of training epochs')
parser.add_argument('--dropout', type=float, default=0.1, help='Dropout rate')
parser.add_argument('--lr', type=float, default=0.001, help='Learning rate')
parser.add_argument('--patience', type=int, default=40, help='Patience for early stopping')
parser.add_argument('--device_num', type=int, default=0, help='GPU device number')
parser.add_argument('--seed', type=int, default=1, help='Random seed')
parser.add_argument('--train_round', type=int, default=10, help='Number of training rounds')

args = parser.parse_args([])
print(args)

# Set random seed for reproducibility
random_seed = args.seed
torch.manual_seed(random_seed)
if torch.cuda.is_available():
    torch.cuda.manual_seed(random_seed)  # Fixed spelling error
    torch.cuda.manual_seed_all(random_seed)
torch.backends.cudnn.benchmark = False
torch.backends.cudnn.deterministic = True

# Device selection
device = torch.device(f'cuda:{args.device_num}' if torch.cuda.is_available() else 'cpu')
print(f"Using device: {device}")

# Load ZINC dataset
train_dataset = ZINC('./dataset/ZINC', subset=True, split='train')
val_dataset = ZINC('./dataset/ZINC', subset=True, split='val')
test_dataset = ZINC('./dataset/ZINC', subset=True, split='test')

# Data loaders
train_loader = DataLoader(train_dataset, args.batch_size, shuffle=True)
val_loader = DataLoader(val_dataset, args.batch_size, shuffle=False)
test_loader = DataLoader(test_dataset, args.batch_size, shuffle=False)

# Create model - now using complete HLGAT model
if args.model == 'HLGAT':
    model = HLGAT_ZINC_Model(
        gnn_layers=args.gnn_layers,
        num_features=21,  # ZINC dataset has 21 atom types
        hidden_dim=args.hidden_dim,
        n_targets=1,
        dropout=args.dropout,
        p_l=args.p_l,
        p_h=args.p_h,
        eps=args.eps
    ).to(device)
elif args.model == 'HLGAT_LPAT':
    model = HLGAT_LPAT_ZINC_Model(
        gnn_layers=args.gnn_layers,
        num_features=21,  # ZINC dataset has 21 atom types
        hidden_dim=args.hidden_dim,
        n_targets=1,
        dropout=args.dropout,
        p_l=args.p_l,
        p_h=args.p_h,
        eps=args.eps,
        omega_init=0.0,
        lambda_init=0.0
    ).to(device)

# Calculate model FLOPs and parameters
data_sample = next(iter(train_loader)).to(device)
total_flops, total_params = get_model_info(model, data_sample)
params_m = f"{total_params/1e6:.2f}M" if total_params > 1e6 else f"{total_params/1e3:.2f}K"
print(f"Model Parameters: {params_m}, FLOPs: {total_flops/1e6:.2f}M")


def train(epoch):
    """Training function for one epoch"""
    model.train()
    total_loss = 0
    for data in train_loader:
        data = data.to(device)
        optimizer.zero_grad()
        out = model(data).squeeze()
        loss = F.l1_loss(out, data.y)  # MAE loss
        loss.backward()
        total_loss += loss.item() * data.num_graphs
        optimizer.step()
    return total_loss / len(train_loader.dataset)


@torch.no_grad()
def test(loader):
    """Testing function"""
    model.eval()
    total_error = 0
    for data in loader:
        data = data.to(device)
        out = model(data).squeeze()
        total_error += F.l1_loss(out, data.y, reduction='sum').item()
    return total_error / len(loader.dataset)


# Training loop
test_maes = []
val_maes = []
epoch_times = []

for round_idx in range(args.train_round):
    # Reset random seed
    torch.manual_seed(args.seed + round_idx)
    if torch.cuda.is_available():
        torch.cuda.manual_seed_all(args.seed + round_idx)
    
    print(f'\n===== Training Round {round_idx+1}/{args.train_round} =====')
    
    # Initialize model and optimizer
    model.reset_parameters()
    optimizer = Adam(model.parameters(), lr=args.lr)
    
    best_val_mae = float('inf')
    best_test_mae = float('inf')
    early_stopper = EarlyStopper(patience=args.patience)
    round_start_time = time.time()
    
    for epoch in range(1, args.epochs + 1):
        epoch_start_time = time.time()
        
        # Training
        train_loss = train(epoch)
        
        # Validation and testing
        val_mae = test(val_loader)
        test_mae = test(test_loader)
        
        epoch_time = time.time() - epoch_start_time
        epoch_times.append(epoch_time)
        
        # Update best results
        if val_mae < best_val_mae:
            best_val_mae = val_mae
            best_test_mae = test_mae
        
        # Print progress
        if epoch % 10 == 0 or epoch == 1:
            print(f'Epoch: {epoch:03d}, Train Loss: {train_loss:.4f}, '
                  f'Val MAE: {val_mae:.4f}, Test MAE: {test_mae:.4f}, Time: {epoch_time:.2f}s')
        
        # Early stopping check
        if early_stopper.early_stop(val_mae):
            print(f"Early stopping at epoch {epoch}")
            break
    
    round_time = time.time() - round_start_time
    val_maes.append(best_val_mae)
    test_maes.append(best_test_mae)
    
    print(f'Round {round_idx+1} completed. Best Val MAE: {best_val_mae:.4f}, Best Test MAE: {best_test_mae:.4f}, Time: {round_time:.2f}s')

# Calculate average results
val_mae_avg = np.mean(val_maes)
val_mae_std = np.std(val_maes)
test_mae_avg = np.mean(test_maes)
test_mae_std = np.std(test_maes)
epoch_time_avg = np.mean(epoch_times) if epoch_times else 0

print('\n===== Final Results =====')
print(f'Average Val MAE: {val_mae_avg:.4f} ± {val_mae_std:.4f}')
print(f'Average Test MAE: {test_mae_avg:.4f} ± {test_mae_std:.4f}')
print(f'Average Epoch Time: {epoch_time_avg:.2f}s')

# Save results
result_str = (f"Model: Model: {args.model},"
              f"Val MAE: {val_mae_avg:.4f}±{val_mae_std:.4f}, "
              f"Test MAE: {test_mae_avg:.4f}±{test_mae_std:.4f}, "
              f"Params: {params_m}, FLOPs: {total_flops/1e6:.2f}M, "
              f"Avg Epoch Time: {epoch_time_avg:.2f}s\n")

with open('zinc_results.txt', 'a') as f:
    f.write(result_str)

print("Results have been saved to zinc_results.txt")