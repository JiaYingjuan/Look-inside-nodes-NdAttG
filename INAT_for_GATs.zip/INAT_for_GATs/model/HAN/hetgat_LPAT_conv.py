import torch
import torch.nn as nn
import torch.nn.functional as F
from torch_geometric.nn import MessagePassing
from torch_geometric.utils import add_self_loops, remove_self_loops, softmax
from torch import Tensor
from torch.nn import Parameter
from torch_geometric.typing import Adj, OptTensor, Size

class HeteGAT_LPAT_Conv(MessagePassing):
    def __init__(self, in_channels, out_channels, heads=1, concat=True,
                 negative_slope=0.2, dropout=0.0, bias=True, residual=False, omega_init: float = 1.0, lambda_init: float = 5.0,**kwargs):
        kwargs.setdefault('aggr', 'add')
        super().__init__(node_dim=0, **kwargs)
        
        self.in_channels = in_channels
        self.out_channels = out_channels
        self.heads = heads
        self.concat = concat
        self.negative_slope = negative_slope
        self.dropout = dropout
        self.residual = residual
        # Save initial values for reset
        self.omega_init = float(omega_init)  
        self.lambda_init = float(lambda_init)  
        self.omega = Parameter(torch.tensor(float(omega_init)))
        self.lambda_ = Parameter(torch.tensor(float(lambda_init)))
        self.varepsilon = 1e-4  # Numerical stability constant
        
        # Linear transformation parameters
        self.lin_src = nn.Linear(in_channels, heads * out_channels, bias=False)
        self.lin_dst = nn.Linear(in_channels, heads * out_channels, bias=False)
        
        # Attention parameters
        self.att_src = nn.Parameter(torch.Tensor(1, heads, out_channels))
        self.att_dst = nn.Parameter(torch.Tensor(1, heads, out_channels))
        
        # Residual connection
        if residual:
            self.res_linear = nn.Linear(in_channels, heads * out_channels, bias=False)
        else:
            self.register_parameter('res_linear', None)
            
        # Bias term
        if bias:
            self.bias = nn.Parameter(torch.Tensor(heads * out_channels))
        else:
            self.register_parameter('bias', None)
            
        self.reset_parameters()

    def reset_parameters(self):
        # Reset LPAT parameters to initial values
        self.omega.data.fill_(float(self.omega_init))
        self.lambda_.data.fill_(float(self.lambda_init))
        nn.init.xavier_uniform_(self.lin_src.weight)
        nn.init.xavier_uniform_(self.lin_dst.weight)
        nn.init.xavier_uniform_(self.att_src)
        nn.init.xavier_uniform_(self.att_dst)
        if self.res_linear is not None:
            nn.init.xavier_uniform_(self.res_linear.weight)
        if self.bias is not None:
            nn.init.zeros_(self.bias)
            
    def _apply_vartheta(self, x: torch.Tensor) -> torch.Tensor:
        """Apply feature scaling transformation (LPAT mechanism)"""
        # Calculate feature mean and variance
        h_mean = x.mean(dim=1, keepdim=True)
        Psi = (x - h_mean) ** 2
        Psi_mean = Psi.mean(dim=1, keepdim=True)
        
        # Calculate scaling factor and apply
        vartheta = torch.sigmoid(self.omega * Psi / (Psi_mean + self.varepsilon) + self.lambda_)
        return x * vartheta

    def forward(self, x, edge_index, size=None, return_attention_weights=False):
        # 1. Apply feature scaling transformation (LPAT)
        x = self._apply_vartheta(x)
        # Feature transformation
        x_src = self.lin_src(x).view(-1, self.heads, self.out_channels)
        x_dst = self.lin_dst(x).view(-1, self.heads, self.out_channels)
        
        # Add self-loops
        edge_index, _ = remove_self_loops(edge_index)
        edge_index, _ = add_self_loops(edge_index, num_nodes=x.size(0))
        
        # Propagate messages
        out = self.propagate(edge_index, x=(x_src, x_dst), size=size)
        
        # Process output
        if self.concat:
            out = out.view(-1, self.heads * self.out_channels)
        else:
            out = out.mean(dim=1)
            
        # Residual connection
        if self.res_linear is not None:
            res = self.res_linear(x)
            out += res
            
        if self.bias is not None:
            out += self.bias
            
        if return_attention_weights:
            return out, self._alpha
        return out

    def message(self, edge_index_i, x_i, x_j, size_i):
        # Calculate attention scores
        x_i = x_i.view(-1, self.heads, self.out_channels)
        x_j = x_j.view(-1, self.heads, self.out_channels)
        
        # Fix: Correctly calculate attention scores
        alpha = (x_i * self.att_src).sum(dim=-1) + (x_j * self.att_dst).sum(dim=-1)
        alpha = F.leaky_relu(alpha, self.negative_slope)
        
        # Fix: Correctly call softmax
        alpha = softmax(alpha, index=edge_index_i, num_nodes=size_i)  # Use num_nodes parameter
        
        # Save attention weights
        self._alpha = alpha
        
        # Apply dropout
        alpha = F.dropout(alpha, p=self.dropout, training=self.training)
        
        return x_j * alpha.view(-1, self.heads, 1)

class RelationAggregator(nn.Module):
    def __init__(self, in_channels, att_size=128, omega_init=1.0, lambda_init=5.0):
        super().__init__()
        # Save initial values for reset
        self.omega_init = float(omega_init)  
        self.lambda_init = float(lambda_init)  
        # Add LPAT parameters
        self.omega = nn.Parameter(torch.tensor(float(omega_init)))
        self.lambda_ = nn.Parameter(torch.tensor(float(lambda_init)))
        self.varepsilon = 1e-4  # Numerical stability constant
        
        self.att_linear = nn.Linear(in_channels, att_size)
        self.att_query = nn.Linear(att_size, 1, bias=False)
        self.reset_parameters()

    def reset_parameters(self):
        # Reset LPAT parameters
        self.omega.data.fill_(self.omega_init)
        self.lambda_.data.fill_(self.lambda_init)
        
        # Reset other parameters
        nn.init.xavier_uniform_(self.att_linear.weight)
        nn.init.zeros_(self.att_linear.bias)
        nn.init.xavier_uniform_(self.att_query.weight)

    def _apply_vartheta(self, x: torch.Tensor) -> torch.Tensor:
        """Apply feature scaling transformation (LPAT mechanism)"""
        # Calculate feature mean and variance
        h_mean = x.mean(dim=-1, keepdim=True)
        Psi = (x - h_mean) ** 2
        Psi_mean = Psi.mean(dim=-1, keepdim=True)
        
        # Calculate scaling factor and apply
        vartheta = torch.sigmoid(self.omega * Psi / (Psi_mean + self.varepsilon) + self.lambda_)
        return x * vartheta

    def forward(self, embeddings, return_attention=False):
        # embeddings: [num_nodes, num_relations, in_channels]
        # 1. Apply feature scaling transformation (LPAT)
        embeddings = self._apply_vartheta(embeddings)
        
        # 2. Calculate attention weights
        v = torch.tanh(self.att_linear(embeddings))  # [N, R, att_size]
        e = self.att_query(v)  # [N, R, 1]
        alpha = F.softmax(e, dim=1)  # [N, R, 1]
        
        # 3. Weighted aggregation
        out = torch.sum(embeddings * alpha, dim=1)  # [N, in_channels]
        
        if return_attention:
            return out, alpha.squeeze(-1)
        return out