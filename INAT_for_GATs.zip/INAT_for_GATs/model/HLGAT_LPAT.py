import torch
import torch.nn as nn
import torch.nn.functional as F
from torch import Tensor
from torch.nn import Parameter
from torch_geometric.nn import MessagePassing
from torch_geometric.nn.dense.linear import Linear
from torch_geometric.typing import Adj, OptTensor, Size
from torch_geometric.utils import add_self_loops, remove_self_loops
from typing import Optional


class HLGATConv_LPAT(MessagePassing):
    def __init__(
        self,
        in_channels: int,
        hidden_dim: int,
        dropout: float = 0.5,
        p_l: float = 0.1,
        p_h: float = 0.5,
        eps: float = 0.8,
        omega_init: float = 1.0,
        lambda_init: float = 5.0,
        **kwargs
    ):
        kwargs.setdefault('aggr', 'add')
        super().__init__(node_dim=0, **kwargs)
        
        self.in_channels = in_channels
        self.hidden_dim = hidden_dim
        self.dropout = dropout
        self.p_l = p_l
        self.p_h = p_h
        self.eps = eps
        
        # Save initial values for reset
        self.omega_init = float(omega_init)  
        self.lambda_init = float(lambda_init)  
        self.omega = Parameter(torch.tensor(float(omega_init)))
        self.lambda_ = Parameter(torch.tensor(float(lambda_init)))
        self.varepsilon = 1e-4  # Numerical stability constant
        
        self.gate_low = Linear(2 * hidden_dim, 1, bias=False)
        self.gate_high = Linear(2 * hidden_dim, 1, bias=False)
        self.WRL = Linear(2 * hidden_dim, hidden_dim, bias=False)
        
        self.reset_parameters()

    def reset_parameters(self):
        # Reset LPAT parameters to initial values
        self.omega.data.fill_(float(self.omega_init))
        self.lambda_.data.fill_(float(self.lambda_init))
        nn.init.xavier_normal_(self.gate_low.weight, gain=1.414)
        nn.init.xavier_normal_(self.gate_high.weight, gain=1.414)
        nn.init.xavier_normal_(self.WRL.weight, gain=1.414)
        
    def _apply_vartheta(self, x: Tensor) -> Tensor:
        """Apply feature scaling transformation (LPAT mechanism)"""
        # Calculate feature mean and variance
        h_mean = x.mean(dim=1, keepdim=True)
        Psi = (x - h_mean) ** 2
        Psi_mean = Psi.mean(dim=1, keepdim=True)
        
        # Calculate scaling factor and apply
        vartheta = torch.sigmoid(self.omega * Psi / (Psi_mean + self.varepsilon) + self.lambda_)
        return x * vartheta

    def forward(self, x: Tensor, edge_index: Adj, norm: Tensor, size: Size = None) -> Tensor:
        # 1. Apply feature scaling transformation (LPAT)
        x = self._apply_vartheta(x)
        
        # Add self-loops and save processed edge index
        edge_index, _ = remove_self_loops(edge_index)
        edge_index, _ = add_self_loops(edge_index, num_nodes=x.size(0))
        
        # Save normalization factor and processed edge index
        self.norm = norm
        self.processed_edge_index = edge_index
        
        # Propagate low-pass and high-pass signals separately
        out_low = self.propagate(edge_index, x=x, mode='low', size=size)
        out_high = self.propagate(edge_index, x=x, mode='high', size=size)
        
        # Combine results
        combined = torch.cat([out_low, out_high], dim=-1)
        return self.WRL(combined)

    def message(self, x_i: Tensor, x_j: Tensor, mode: str, index: Tensor) -> Tensor:
        """Construct messages to node i for aggregation"""
        # Concatenate source and target node features
        h2 = torch.cat([x_i, x_j], dim=-1)
        
        # Apply gating mechanism
        if mode == 'low':
            _gate = self.gate_low(h2)
            g = F.relu(torch.where(_gate > 0, _gate, -self.p_l * _gate))
        else:  # mode == 'high'
            _gate = self.gate_high(h2)
            g = -F.relu(torch.where(_gate > 0, _gate, -self.p_h * _gate))
        
        # Ensure correct tensor shape
        g = g.squeeze()
        
        # Get source node indices
        _, col = self.processed_edge_index
        source_nodes = col[:x_j.size(0)]
        
        # Get normalization factors
        norm_i = self.norm[index]  # Target node normalization
        norm_j = self.norm[source_nodes]  # Source node normalization
        
        # Calculate edge weights
        edge_weight = g * norm_i * norm_j
        edge_weight = F.dropout(edge_weight, p=self.dropout, training=self.training)
        
        return x_j * edge_weight.view(-1, 1)

    def __repr__(self) -> str:
        return (f'{self.__class__.__name__}({self.in_channels}, '
                f'hidden={self.hidden_dim})')


class HLGAT_LPAT(nn.Module):
    def __init__(
        self,
        in_channels: int,
        hidden_dim: int,
        out_channels: int,
        num_layers: int = 2,
        dropout: float = 0.5,
        p_l: float = 0.1,
        p_h: float = 0.5,
        eps: float = 0.8,
        omega_init: float = 1.0,
        lambda_init: float = 5.0
    ):
        super().__init__()
        self.in_channels = in_channels
        self.hidden_dim = hidden_dim
        self.out_channels = out_channels
        self.num_layers = num_layers
        self.dropout = dropout
        self.eps = eps
        
        # Input transformation layer
        self.t1 = Linear(in_channels, hidden_dim)
        
        # HLGAT convolutional layers
        self.convs = nn.ModuleList([
            HLGATConv_LPAT(
                in_channels=hidden_dim,
                hidden_dim=hidden_dim,
                dropout=dropout,
                p_l=p_l,
                p_h=p_h,
                eps=eps,
                omega_init=omega_init,  # Pass LPAT parameters
                lambda_init=lambda_init  # Pass LPAT parameters
            ) for _ in range(num_layers)
        ])
        
        # Output layer
        self.t2 = Linear(hidden_dim, out_channels)
        
        self.reset_parameters()

    def reset_parameters(self):
        nn.init.xavier_normal_(self.t1.weight, gain=1.414)
        nn.init.xavier_normal_(self.t2.weight, gain=1.414)
        # Reset convolutional layer parameters (including LPAT parameters)
        for conv in self.convs:
            conv.reset_parameters()
    
    def forward(
        self, 
        x: Tensor, 
        edge_index: Adj,
        norm: Tensor
    ) -> Tensor:
        # Input transformation
        x = F.dropout(x, p=self.dropout, training=self.training)
        x = F.relu(self.t1(x))
        x = F.dropout(x, p=self.dropout, training=self.training)
        
        # Save residual connection
        raw = x
        
        # Process through HLGAT layers
        for conv in self.convs:
            x = conv(x, edge_index, norm)
            x = self.eps * raw + x  # Residual connection
        
        # Output transformation
        return self.t2(x)
    
    def __repr__(self) -> str:
        return (f'{self.__class__.__name__}(in={self.in_channels}, '
                f'hidden={self.hidden_dim}, out={self.out_channels}, '
                f'layers={self.num_layers})')