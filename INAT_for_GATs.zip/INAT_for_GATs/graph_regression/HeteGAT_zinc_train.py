import os
import sys
import gc
import argparse
import torch
import time
import numpy as np
import pandas as pd
from torch.optim import Adam
import torch.nn as nn
from torch_geometric.datasets import ZINC
from torch_geometric.loader import DataLoader
from torch_geometric.nn import global_add_pool
from thop import profile
from torch_geometric.nn import MessagePassing
from torch_geometric.data import Data, Batch

# Get the absolute path of current file
current_dir = os.path.dirname(os.path.abspath(__file__))
project_root = os.path.dirname(os.path.dirname(os.path.dirname(current_dir)))
sys.path.insert(0, project_root)
from model.HAN.HeteGAT import HeteGAT  # Import HeteGAT model
from model.HAN.HeteGAT_LPAT import HeteGAT_LPAT


class EarlyStopper:
    """Early stopping utility to prevent overfitting"""
    
    def __init__(self, patience=1, min_delta=0):
        self.patience = patience
        self.min_delta = min_delta
        self.counter = 0
        self.min_validation_loss = float('inf')

    def early_stop(self, validation_loss):
        """Check if training should stop early"""
        if validation_loss < self.min_validation_loss:
            self.min_validation_loss = validation_loss
            self.counter = 0
        elif validation_loss >= (self.min_validation_loss + self.min_delta):
            self.counter += 1
            if self.counter >= self.patience:
                return True
        return False


class HeteGATZINCModel(nn.Module):
    """HeteGAT Model for ZINC dataset regression task"""
    
    def __init__(self, gnn_layers, num_features, hidden_dim, num_relations, 
                 att_size, n_targets, dropout, embedding_layer=False):
        super().__init__()
        self.embedding_layer = embedding_layer
        self.num_relations = num_relations
        
        # Node embedding layer
        if embedding_layer:
            self.node_emb = nn.Embedding(num_features, 100)
            in_channels = 100
        else:
            in_channels = num_features
        
        # HeteGAT encoder
        self.encoder = HeteGAT(
            in_channels=in_channels,
            hidden_channels=hidden_dim,
            out_channels=hidden_dim,  # Output node embedding dimension
            heads=1,  # Graph regression tasks typically use fewer attention heads
            num_relations=num_relations,
            num_layers=gnn_layers,
            att_size=att_size,
            dropout=dropout,
            residual=True,
            return_attention=False
        )
        
        # Regression head
        self.regressor = nn.Sequential(
            nn.Linear(hidden_dim, hidden_dim),
            nn.ReLU(),
            nn.Dropout(dropout),
            nn.Linear(hidden_dim, n_targets)
        )
        
        self.dropout = nn.Dropout(dropout)
        
    def reset_parameters(self):
        """Reset model parameters"""
        for module in self.modules():
            if hasattr(module, 'reset_parameters'):
                module.reset_parameters()
    
    def forward(self, data, relation_edge_indices):
        """Forward pass through the model"""
        # Node embedding
        if self.embedding_layer:
            x = self.node_emb(data.x).squeeze()
        else:
            x = data.x
        
        # Pass through HeteGAT encoder
        x = self.encoder(x, relation_edge_indices)
        
        # Global pooling
        x = global_add_pool(x, data.batch)
        
        # Regression prediction
        x = self.regressor(x)
        return x.squeeze()
    

class HeteGAT_LPAT_ZINCModel(nn.Module):
    """HeteGAT LPAT Model for ZINC dataset regression task"""
    
    def __init__(self, gnn_layers, num_features, hidden_dim, num_relations, 
                 att_size, n_targets, dropout, embedding_layer=False, omega_init=1.0, lambda_init=5.0):
        super().__init__()
        self.embedding_layer = embedding_layer
        self.num_relations = num_relations
        
        # Node embedding layer
        if embedding_layer:
            self.node_emb = nn.Embedding(num_features, 100)
            in_channels = 100
        else:
            in_channels = num_features
        
        # HeteGAT_LPAT encoder
        self.encoder = HeteGAT_LPAT(
            in_channels=in_channels,
            hidden_channels=hidden_dim,
            out_channels=hidden_dim,  # Output node embedding dimension
            heads=1,  # Graph regression tasks typically use fewer attention heads
            num_relations=num_relations,
            num_layers=gnn_layers,
            att_size=att_size,
            dropout=dropout,
            residual=True,
            return_attention=False,
            omega_init=omega_init,
            lambda_init=lambda_init
        )
        
        # Regression head
        self.regressor = nn.Sequential(
            nn.Linear(hidden_dim, hidden_dim),
            nn.ReLU(),
            nn.Dropout(dropout),
            nn.Linear(hidden_dim, n_targets)
        )
        
        self.dropout = nn.Dropout(dropout)
        
    def reset_parameters(self):
        """Reset model parameters"""
        for module in self.modules():
            if hasattr(module, 'reset_parameters'):
                module.reset_parameters()
    
    def forward(self, data, relation_edge_indices):
        """Forward pass through the model"""
        # Node embedding
        if self.embedding_layer:
            x = self.node_emb(data.x).squeeze()
        else:
            x = data.x
        
        # Pass through HeteGAT_LPAT encoder
        x = self.encoder(x, relation_edge_indices)
        
        # Global pooling
        x = global_add_pool(x, data.batch)
        
        # Regression prediction
        x = self.regressor(x)
        return x.squeeze()


def build_heterogeneous_relations(edge_index, num_nodes, num_relations=3):
    """
    Build multi-relation graph data for a single graph
    
    Parameters:
        edge_index: Original edge index [2, num_edges]
        num_nodes: Number of nodes in the graph
        num_relations: Number of relations to create
        
    Returns:
        relation_edge_indices: List of relation edge indices
    """
    device = edge_index.device
    relation_edge_indices = []
    
    # Relation 1: Original relation
    relation_edge_indices.append(edge_index)
    
    # Relation 2: Reverse relation
    reverse_edge_index = torch.stack([edge_index[1], edge_index[0]], dim=0)
    relation_edge_indices.append(reverse_edge_index)
    
    # Relation 3: Self-loop relation
    self_loop = torch.arange(num_nodes, device=device).repeat(2, 1)
    relation_edge_indices.append(self_loop)
    
    # If more relations are needed, generate randomly
    for i in range(3, num_relations):
        num_edges = edge_index.size(1)
        sample_size = int(num_edges * 0.7)  # Use 70% of edges
        indices = torch.randperm(num_edges, device=device)[:sample_size]
        sampled_edges = edge_index[:, indices]
        relation_edge_indices.append(sampled_edges)
    
    return relation_edge_indices


def collate_with_relations(batch, num_relations=3):
    """More robust batch processing function"""
    # Create standard batched graph
    data = Batch.from_data_list(batch)
    
    # Build multi-relation graphs for each graph in the batch
    relation_edge_indices_list = []
    for graph in batch:
        # Ensure we're using the edge_index attribute
        if not hasattr(graph, 'edge_index') or not isinstance(graph.edge_index, torch.Tensor):
            # Create empty edge index
            graph.edge_index = torch.empty((2, 0), dtype=torch.long, device=graph.x.device)
            
        graph_relations = build_heterogeneous_relations(
            graph.edge_index, 
            graph.num_nodes,
            num_relations
        )
        relation_edge_indices_list.append(graph_relations)
    
    batch_relation_edge_indices = []
    
    # Process each relation type separately
    for rel_idx in range(num_relations):
        rel_edges = []
        offset = 0
        for i, graph in enumerate(batch):
            graph_rel_edges = relation_edge_indices_list[i][rel_idx]
            
            # Ensure it's a tensor
            if not isinstance(graph_rel_edges, torch.Tensor):
                # If it's a tuple, try to convert
                if isinstance(graph_rel_edges, tuple):
                    # Keep only tensor elements
                    graph_rel_edges = [t for t in graph_rel_edges if isinstance(t, torch.Tensor)]
                    if len(graph_rel_edges) == 2:
                        graph_rel_edges = torch.stack(graph_rel_edges, dim=0)
                    else:
                        # Create empty edge index
                        graph_rel_edges = torch.empty((2, 0), dtype=torch.long, device=graph.x.device)
                else:
                    # Create empty edge index
                    graph_rel_edges = torch.empty((2, 0), dtype=torch.long, device=graph.x.device)
            
            # Adjust node indices
            adjusted_edges = graph_rel_edges + offset
            rel_edges.append(adjusted_edges)
            offset += graph.num_nodes
        
        # Merge all edges for current relation
        if rel_edges:
            batch_relation_edge_indices.append(torch.cat(rel_edges, dim=1))
        else:
            batch_relation_edge_indices.append(torch.empty((2, 0), dtype=torch.long))
    
    # Ensure only two elements are returned
    return (data, batch_relation_edge_indices)


# Argument parser configuration
parser = argparse.ArgumentParser(description='HeteGAT for ZINC Regression')
parser.add_argument('--model', type=str, default='HeteGAT_LPAT', help='Model type to use')
parser.add_argument('--batch-size', type=int, default=128, help='Input batch size for training')
parser.add_argument('--epochs', type=int, default=300, help='Number of epochs to train')
parser.add_argument('--gnn-layers', type=int, default=4, help='Number of GNN layers')
parser.add_argument('--hidden-dim', type=int, default=128, help='Hidden dimension size')
parser.add_argument('--num-relations', type=int, default=3, help='Number of relations in the graph')
parser.add_argument('--att-size', type=int, default=128, help='Relation attention size')
parser.add_argument('--dropout', type=float, default=0.0, help='Dropout rate')
parser.add_argument('--patience', type=int, default=20, help='Patience for early stopping')
parser.add_argument('--device_num', type=int, default=0, help='GPU device number')
parser.add_argument('--seed', type=int, default=1, help='Random seed')
parser.add_argument('--lr', type=float, default=0.001, help='Learning rate')
parser.add_argument('--train_round', type=int, default=10, help='Number of training rounds')

args = parser.parse_args()
print(args)

# Random seed setting
random_seed = args.seed
torch.manual_seed(random_seed)
if torch.cuda.is_available():
    torch.cuda.manual_seed(random_seed)
    torch.cuda.manual_seed_all(random_seed)
torch.backends.cudnn.benchmark = False
torch.backends.cudnn.deterministic = True

# Device selection
device = torch.device(f'cuda:{args.device_num}' if torch.cuda.is_available() else 'cpu')

# Load dataset
train_dataset = ZINC('./dataset/ZINC', subset=True, split='train')
val_dataset = ZINC('./dataset/ZINC', subset=True, split='val')
test_dataset = ZINC('./dataset/ZINC', subset=True, split='test')

# Create data loaders (using custom collate function)
def create_collate_fn(num_relations):
    return lambda batch: collate_with_relations(batch, num_relations)

train_loader = DataLoader(
    train_dataset, 
    args.batch_size, 
    shuffle=True,
    collate_fn=create_collate_fn(args.num_relations)
)

val_loader = DataLoader(
    val_dataset, 
    args.batch_size, 
    shuffle=False,
    collate_fn=create_collate_fn(args.num_relations)
)

test_loader = DataLoader(
    test_dataset, 
    args.batch_size, 
    shuffle=False,
    collate_fn=create_collate_fn(args.num_relations)
)

# Create model
if args.model == 'HeteGAT':
    model = HeteGATZINCModel(
        gnn_layers=args.gnn_layers,
        num_features=21,  # ZINC dataset has 21 atom types
        hidden_dim=args.hidden_dim,
        num_relations=args.num_relations,
        att_size=args.att_size,
        n_targets=1,  # Regression task outputs one value
        dropout=args.dropout,
        embedding_layer=True  # Use embedding layer for atom types
    ).to(device)
elif args.model == 'HeteGAT_LPAT':
    model = HeteGAT_LPAT_ZINCModel(
        gnn_layers=args.gnn_layers,
        num_features=21,  # ZINC dataset has 21 atom types
        hidden_dim=args.hidden_dim,
        num_relations=args.num_relations,
        att_size=args.att_size,
        n_targets=1,  # Regression task outputs one value
        dropout=args.dropout,
        embedding_layer=True,
        omega_init=1.0,
        lambda_init=5.0
    ).to(device)

optimizer = Adam(model.parameters(), lr=args.lr)


def get_model_info(model, data_sample):
    """Function to get model FLOPs and parameter count"""
    # Count parameter number
    total_params = sum(p.numel() for p in model.parameters() if p.requires_grad)
    
    # Manual FLOPs estimation
    num_nodes = data_sample.x.size(0)
    num_edges = data_sample.edge_index.size(1) * args.num_relations  # Estimated value
    
    flops = 0
    in_dim = 100  # Embedding layer output dimension
    hidden_dim = args.hidden_dim
    num_layers = args.gnn_layers
    num_relations = args.num_relations
    att_size = args.att_size
    
    # Embedding layer
    flops += num_nodes * 21 * 100  # 21 atom types embedded to 100 dimensions
    
    # HeteGAT encoder
    # Input transformation
    flops += num_nodes * in_dim * hidden_dim
    
    # GAT layer computation
    for i in range(num_layers):
        # Computation for each relation per layer
        flops += num_relations * num_edges * hidden_dim
        
        # If not the last layer, perform relation aggregation
        if i < num_layers - 1:
            flops += num_nodes * num_relations * hidden_dim * att_size
            flops += num_nodes * num_relations * att_size  # Attention computation
    
    # Regression head
    flops += num_nodes * hidden_dim * hidden_dim  # First linear layer
    flops += num_nodes * hidden_dim * 1  # Second linear layer
    
    return flops, total_params


# Get sample data for FLOPs calculation
sample_batch = next(iter(train_loader))
# Ensure only the first two elements are retrieved
data_sample = sample_batch[0].to(device)  # First element of tuple is data

total_flops, total_params = get_model_info(model, data_sample)
flops_m = total_flops / 1e6  # Convert to MFLOPs

print(f"Model Parameters: {total_params}")
print(f"Model FLOPs: {flops_m:.2f}M")


def train():
    """Training function"""
    model.train()
    total_loss = 0
    total_graphs = 0
    
    for batch in train_loader:
        # Use index access to avoid unpacking issues
        data = batch[0].to(device)
        relation_edge_indices = batch[1]
        
        # Ensure each relation edge index is a tensor
        processed_rels = []
        for rel in relation_edge_indices:
            # If it's a tuple, keep only tensor elements and convert
            if isinstance(rel, tuple):
                # Filter out non-tensor elements
                tensor_elements = [t for t in rel if isinstance(t, torch.Tensor)]
                if len(tensor_elements) == 2:
                    rel = torch.stack(tensor_elements, dim=0)
                else:
                    # Create empty edge index
                    rel = torch.empty((2, 0), dtype=torch.long, device=device)
            # If it's another type, try to convert
            elif not isinstance(rel, torch.Tensor):
                # Try to convert to tensor
                try:
                    rel = torch.tensor(rel, dtype=torch.long, device=device)
                except:
                    # Create empty edge index
                    rel = torch.empty((2, 0), dtype=torch.long, device=device)
            
            # Move to device
            processed_rels.append(rel.to(device))
        
        optimizer.zero_grad()
        out = model(data, processed_rels)
        loss = (out - data.y).abs().mean()
        loss.backward()
        
        # Calculate number of graphs in current batch
        num_graphs = data.y.size(0)  # Use target value count as graph count
        total_loss += loss.item() * num_graphs
        total_graphs += num_graphs
        
        optimizer.step()
    
    if total_graphs == 0:
        return float('inf')
    return total_loss / total_graphs


@torch.no_grad()
def test(loader):
    """Testing function - use index access to avoid unpacking issues"""
    model.eval()
    total_error = 0
    total_graphs = 0
    
    for batch in loader:
        # Use index access to avoid unpacking issues
        data = batch[0].to(device)
        relation_edge_indices = batch[1]
        
        # Ensure each relation edge index is a tensor
        processed_rels = []
        for rel in relation_edge_indices:
            # If it's a tuple, keep only tensor elements and convert
            if isinstance(rel, tuple):
                # Filter out non-tensor elements
                tensor_elements = [t for t in rel if isinstance(t, torch.Tensor)]
                if len(tensor_elements) == 2:
                    rel = torch.stack(tensor_elements, dim=0)
                else:
                    # Create empty edge index
                    rel = torch.empty((2, 0), dtype=torch.long, device=device)
            # If it's another type, try to convert
            elif not isinstance(rel, torch.Tensor):
                # Try to convert to tensor
                try:
                    rel = torch.tensor(rel, dtype=torch.long, device=device)
                except:
                    # Create empty edge index
                    rel = torch.empty((2, 0), dtype=torch.long, device=device)
            
            # Move to device
            processed_rels.append(rel.to(device))
        
        out = model(data, processed_rels)
        error = (out - data.y).abs().sum().item()
        num_graphs = data.y.size(0)
        total_error += error
        total_graphs += num_graphs
    
    if total_graphs == 0:
        return float('inf')
    return total_error / total_graphs


# Training loop
val_maes = []
test_maes = []
epoch_times = []

for run in range(args.train_round):
    # Reset random seed
    torch.manual_seed(args.seed + run)
    if torch.cuda.is_available():
        torch.cuda.manual_seed_all(args.seed + run)
    
    print(f"\n=== Run {run+1}/5 ===")
    
    # Reset model and optimizer
    if args.model == 'HeteGAT':
        model = HeteGATZINCModel(
            gnn_layers=args.gnn_layers,
            num_features=21,  # ZINC dataset has 21 atom types
            hidden_dim=args.hidden_dim,
            num_relations=args.num_relations,
            att_size=args.att_size,
            n_targets=1,  # Regression task outputs one value
            dropout=args.dropout,
            embedding_layer=True  # Use embedding layer for atom types
        ).to(device)
    elif args.model == 'HeteGAT_LPAT':
        model = HeteGAT_LPAT_ZINCModel(
            gnn_layers=args.gnn_layers,
            num_features=21,  # ZINC dataset has 21 atom types
            hidden_dim=args.hidden_dim,
            num_relations=args.num_relations,
            att_size=args.att_size,
            n_targets=1,  # Regression task outputs one value
            dropout=args.dropout,
            embedding_layer=True,
            omega_init=0.0,
            lambda_init=0.0
        ).to(device)
    
    optimizer = Adam(model.parameters(), lr=args.lr)
    early_stopper = EarlyStopper(patience=args.patience)
    
    best_val_mae = float('inf')
    best_test_mae = float('inf')
    run_epoch_times = []
    
    for epoch in range(1, args.epochs + 1):
        epoch_start = time.time()
        
        # Training
        try:
            train_loss = train()
        except Exception as e:
            print(f"Error during training: {e}")
            train_loss = float('inf')
            # Skip validation and testing
            val_mae = float('inf')
            test_mae = float('inf')
        else:
            # Validation
            try:
                val_mae = test(val_loader)
                test_mae = test(test_loader)
            except Exception as e:
                print(f"Error during testing: {e}")
                val_mae = float('inf')
                test_mae = float('inf')
        
        epoch_time = time.time() - epoch_start
        run_epoch_times.append(epoch_time)
        
        print(f'Epoch {epoch:03d}: Train Loss: {train_loss:.4f}, Val MAE: {val_mae:.4f}, Test MAE: {test_mae:.4f}, Time: {epoch_time:.2f}s')
        
        # Update best results
        if val_mae < best_val_mae:
            best_val_mae = val_mae
            best_test_mae = test_mae
        
        # Early stopping check
        if val_mae < float('inf') and early_stopper.early_stop(val_mae):
            print(f"Early stopping at epoch {epoch}")
            break
    
    val_maes.append(best_val_mae)
    test_maes.append(best_test_mae)
    epoch_times.append(np.mean(run_epoch_times))
    
    print(f"Run {run+1} completed. Best Val MAE: {best_val_mae:.4f}, Best Test MAE: {best_test_mae:.4f}")

# Calculate average results
val_maes = [v for v in val_maes if v < float('inf')]
test_maes = [t for t in test_maes if t < float('inf')]
epoch_times = [t for t in epoch_times if not np.isnan(t)]

if len(val_maes) == 0:
    val_mae_avg = float('inf')
    val_mae_std = float('nan')
    test_mae_avg = float('inf')
    test_mae_std = float('nan')
    time_avg = float('nan')
else:
    val_mae_avg = np.mean(val_maes)
    val_mae_std = np.std(val_maes)
    test_mae_avg = np.mean(test_maes)
    test_mae_std = np.std(test_maes)
    time_avg = np.mean(epoch_times)

print('\n' + '=' * 80)
print('Training completed.')
print(f'Average Val MAE: {val_mae_avg:.4f} ± {val_mae_std:.4f}')
print(f'Average Test MAE: {test_mae_avg:.4f} ± {test_mae_std:.4f}')
print(f'Average Epoch Time: {time_avg:.4f}s')
print(f'Model Parameters: {total_params}')
print(f'Model FLOPs: {flops_m:.2f}M')

# Save results to file
result_str = (f"Model: {args.model},"
             f"Avg Test MAE: {test_mae_avg:.4f} ± {test_mae_std:.4f},"
             f"Avg Epoch Time: {time_avg:.4f}s,"
             f"Params: {total_params}, FLOPs: {flops_m:.2f}M\n")

# Write results to file
result_filename = "zinc_results.txt"
with open(result_filename, 'a') as f:
    f.write(result_str)

print(f"Results saved to {result_filename}")