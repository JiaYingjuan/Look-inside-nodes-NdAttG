import os
import sys
import torch
import argparse
from torch_geometric.datasets import Planetoid
import numpy as np
import torch_geometric.transforms as T
import torch.nn.functional as F
from torch import nn
import time
from torch_geometric.utils import degree

# Get the four-level absolute path of the current file
current_dir = os.path.dirname(os.path.abspath(__file__))
project_root = os.path.dirname(os.path.dirname(os.path.dirname(current_dir)))
sys.path.insert(0, project_root)

# Import HLGAT models
from model.HLGAT import HLGAT
from model.HLGAT_LPAT import HLGAT_LPAT

parser = argparse.ArgumentParser(description='PyTorch HLGAT implementation.')

# HLGAT specific parameters
parser.add_argument('--model', type=str, default='HLGAT_LPAT', help='the used model type')
parser.add_argument('--hidden_dim', type=int, default=32, help='the hidden dimension')
parser.add_argument('--num_layers', type=int, default=2, help='the number of HLGAT layers')
parser.add_argument('--p_l', type=float, default=0.1, help='leak coefficient for low-pass filter')
parser.add_argument('--p_h', type=float, default=0.5, help='leak coefficient for high-pass filter')
parser.add_argument('--eps', type=float, default=0.8, help='residual connection weight')

# General training parameters
parser.add_argument('--device_num', type=int, default=0, help='the device number')
parser.add_argument('--epoch_num', type=int, default=300, help='the epoch number')
parser.add_argument('--lr', type=float, default=0.005, help='the learning rate')
parser.add_argument('--drop_rate', type=float, default=0.3, help='the dropping rate')

# Dataset and evaluation parameters
parser.add_argument('--seed', type=int, default=1, help='the random seed')
parser.add_argument('--dataset', type=str, default='Cora', help='the test dataset')
parser.add_argument('--train_round', type=int, default=10, help='the train round number')
parser.add_argument('--file_id', type=int, default=0, help='the file id')

args = parser.parse_args()

# Set random seed
random_seed = args.seed
torch.manual_seed(random_seed)
if torch.cuda.is_available():
    torch.cuda.manual_seed(random_seed)
    torch.cuda.manual_seed_all(random_seed)
torch.backends.cudnn.benchmark = False
torch.backends.cudnn.deterministic = True

# Device selection
device = torch.device(f'cuda:{args.device_num}' if torch.cuda.is_available() else 'cpu')
print(f"Using device: {device}")

# Load dataset
dataset = Planetoid(root="./dataset/", name=args.dataset, transform=T.NormalizeFeatures())
data = dataset[0].to(device=device)

# Calculate degree normalization factor
deg = degree(data.edge_index[0], num_nodes=data.num_nodes).float().clamp(min=1)
norm = deg.pow(-0.5).to(device)

# HLGAT model definition
class HLGATModel(nn.Module):
    def __init__(self, in_channels, hidden_dim, out_channels, num_layers, dropout, p_l, p_h, eps):
        super(HLGATModel, self).__init__()
        self.hlgat = HLGAT(
            in_channels=in_channels,
            hidden_dim=hidden_dim,
            out_channels=out_channels,
            num_layers=num_layers,
            dropout=dropout,
            p_l=p_l,
            p_h=p_h,
            eps=eps
        )
        
    def forward(self, x, edge_index, norm):
        return self.hlgat(x, edge_index, norm)
    
    def reset_parameters(self):
        self.hlgat.reset_parameters()
        
# HLGAT_LPAT model definition
class HLGATModel_LPAT(nn.Module):
    def __init__(self, in_channels, hidden_dim, out_channels, num_layers, dropout, p_l, p_h, eps, omega_init, lambda_init):
        super(HLGATModel_LPAT, self).__init__()
        self.hlgat_LPAT = HLGAT_LPAT(
            in_channels=in_channels,
            hidden_dim=hidden_dim,
            out_channels=out_channels,
            num_layers=num_layers,
            dropout=dropout,
            p_l=p_l,
            p_h=p_h,
            eps=eps,
            omega_init=omega_init,
            lambda_init=lambda_init
        )
        
    def forward(self, x, edge_index, norm):
        return self.hlgat_LPAT(x, edge_index, norm)
    
    def reset_parameters(self):
        self.hlgat_LPAT.reset_parameters()

if args.model == 'HLGAT':
    # Initialize model
    model = HLGATModel(
        in_channels=dataset.num_features,
        hidden_dim=args.hidden_dim,
        out_channels=dataset.num_classes,
        num_layers=args.num_layers,
        dropout=args.drop_rate,
        p_l=args.p_l,
        p_h=args.p_h,
        eps=args.eps
    ).to(device)
elif args.model == 'HLGAT_LPAT':
    # Initialize model
    model = HLGATModel_LPAT(
        in_channels=dataset.num_features,
        hidden_dim=args.hidden_dim,
        out_channels=dataset.num_classes,
        num_layers=args.num_layers,
        dropout=args.drop_rate,
        p_l=args.p_l,
        p_h=args.p_h,
        eps=args.eps,
        omega_init=1.0,
        lambda_init=5.0
    ).to(device)
    
# Calculate FLOPs and parameter count
def get_flops_and_params(model, x, edge_index, norm):
    """Calculate model FLOPs and parameter count"""
    N = x.size(0)  # Number of nodes
    E = edge_index.size(1)  # Number of edges
    F_in = x.size(1)  # Input feature dimension
    
    total_flops = 0
    total_params = 0
    
    # Calculate parameter count
    for name, param in model.named_parameters():
        if param.requires_grad:
            total_params += param.numel()
    
    # Calculate FLOPs for HLGAT layers
    for i in range(args.num_layers):
        if i == 0:
            in_dim = F_in
        else:
            in_dim = args.hidden_dim
            
        if i == args.num_layers - 1:
            out_dim = dataset.num_classes
        else:
            out_dim = args.hidden_dim
            
        # FLOPs for linear transformation (2 * in_dim * out_dim * N)
        total_flops += 2 * N * in_dim * out_dim
        
        # FLOPs for graph convolution operations (approximately 4 operations per edge * E)
        total_flops += 4 * E
        
        # FLOPs for filtering operations (2 operations per node * N)
        total_flops += 2 * N
        
        # FLOPs for residual connections (1 operation per node * N * out_dim)
        total_flops += N * out_dim
    
    # If it's an LPAT model, add FLOPs for LPAT mechanism
    if args.model == 'HLGAT_LPAT':
        # LPAT mechanism computation:
        # 1. Calculate feature mean: N * F_in
        # 2. Calculate feature variance: 3 * N * F_in (subtraction, squaring, summation)
        # 3. Calculate scaling factor: 3 * N * F_in (division, multiplication, addition)
        # 4. Apply scaling: N * F_in (multiplication)
        total_flops += (N * F_in) + (3 * N * F_in) + (3 * N * F_in) + (N * F_in)
    
    # Add FLOPs for activation functions (1 operation per node * N * out_dim)
    # Note: The last layer usually doesn't have an activation function
    for i in range(args.num_layers - 1):
        total_flops += N * out_dim
    
    # Add FLOPs for dropout (1 operation per node * N * out_dim)
    # Note: The first layer doesn't have dropout
    for i in range(1, args.num_layers):
        total_flops += N * out_dim
    
    return total_flops, total_params

flops_total, params_m = get_flops_and_params(model, data.x, data.edge_index, norm)
flops_m = flops_total / 1000000

# Optimizer
optimizer = torch.optim.Adam(model.parameters(), lr=args.lr, weight_decay=5e-4)

def train():
    model.train()
    optimizer.zero_grad()
    out = model(data.x, data.edge_index, norm)
    loss = F.cross_entropy(out[data.train_mask], data.y[data.train_mask])
    loss.backward()
    optimizer.step()
    return loss.item()

@torch.no_grad()
def test():
    model.eval()
    out = model(data.x, data.edge_index, norm)
    
    # Calculate training set accuracy
    train_pred = out[data.train_mask].max(1)[1]
    train_acc = train_pred.eq(data.y[data.train_mask]).sum().item() / data.train_mask.sum().item()
    
    # Calculate validation set accuracy
    val_pred = out[data.val_mask].max(1)[1]
    val_acc = val_pred.eq(data.y[data.val_mask]).sum().item() / data.val_mask.sum().item()
    
    # Calculate test set accuracy
    test_pred = out[data.test_mask].max(1)[1]
    test_acc = test_pred.eq(data.y[data.test_mask]).sum().item() / data.test_mask.sum().item()
    
    return train_acc, val_acc, test_acc

# Training loop
test_acc_list = []
time_list = []
for round_idx in range(args.train_round):
    # Reset random seed
    torch.manual_seed(args.seed + round_idx)
    if torch.cuda.is_available():
        torch.cuda.manual_seed_all(args.seed + round_idx)
    
    print(f'\n===== Training Round {round_idx+1}/{args.train_round} =====')
    
    start_time = time.time()
    best_val_acc = 0.0
    best_test_acc = 0.0
    model.reset_parameters()
    optimizer = torch.optim.Adam(model.parameters(), lr=args.lr, weight_decay=5e-4)
    
    for epoch in range(1, args.epoch_num + 1):
        loss = train()
        train_acc, val_acc, test_acc = test()
        
        # Update best test accuracy
        if val_acc > best_val_acc:
            best_val_acc = val_acc
            best_test_acc = test_acc
        
        # Print progress every 10 epochs
        if epoch % 10 == 0 or epoch == 1:
            print(f'Epoch: {epoch:03d}, Loss: {loss:.4f}, '
                  f'Train: {train_acc:.4f}, Val: {val_acc:.4f}, Test: {test_acc:.4f}')
    
    end_time = time.time()
    round_time = end_time - start_time
    time_list.append(round_time)
    test_acc_list.append(best_test_acc)
    
    print(f'Round {round_idx+1} completed. Best Test Acc: {best_test_acc:.4f}, Time: {round_time:.2f}s')

# Calculate average accuracy and standard deviation
acc_avg = np.mean(test_acc_list)
acc_std = np.std(test_acc_list)
time_avg = np.mean(time_list)

print('\n===== Final Results =====')
print(f'Average Test Accuracy: {acc_avg:.4f} ± {acc_std:.4f}')
print(f'Average Training Time per Round: {time_avg:.2f}s')

# Save results
result_str = (f"Model: {args.model}, Dataset: {args.dataset}, "
             f"Avg Acc: {acc_avg:.4f}±{acc_std:.4f}, "
             f"Time: {time_avg:.2f}s, "
             f"Flops: {flops_m:.2f}M, "
             f"Params: {params_m}\n")

# Write results to file
with open('results.txt', 'a') as f:  # Use append mode
    f.write(result_str)

print("Results have been saved to results.txt")