#!/bin/bash

BASE_DIR=$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)
cd $BASE_DIR

export PYTHONPATH="$BASE_DIR:$PYTHONPATH"

### Amazon-Photo


# #### GAT

# # python -m node_classification.train_amazon \
# #   --dataset Photo \
# #   --model GAT \
# #   --hidden_dim 64 \
# #   --heads 2 \
# #   --drop_rate 0.5
  
# #### GAT+LPAT

# python -m node_classification.train_amazon \
#   --dataset Photo \
#   --model GAT_LPAT \
#   --hidden_dim 64 \
#   --heads 2 \
#   --drop_rate 0.5
  
# # #### GATv2

# # python -m node_classification.train_amazon \
# #   --dataset Photo \
# #   --model GATv2 \
# #   --hidden_dim 64 \
# #   --heads 2 \
# #   --drop_rate 0.5
  
# # #### GATv2+LPAT

# python -m node_classification.train_amazon \
#   --dataset Photo \
#   --model GATv2_LPAT \
#   --hidden_dim 64 \
#   --heads 2 \
#   --drop_rate 0.5
  
# # #### KAAGAT

# # python -m node_classification.train_amazon \
# #   --dataset Photo \
# #   --model KAAGAT \
# #   --hidden_dim 64 \
# #   --heads 2 \
# #   --drop_rate 0.5
  
# # #### KAAGAT+LPAT

# python -m node_classification.train_amazon \
#   --dataset Photo \
#   --model KAAGAT_LPAT \
#   --hidden_dim 64 \
#   --heads 2 \
#   --drop_rate 0.5

# # #### GLCN

# # python -m node_classification.train_amazon \
# #   --dataset Photo \
# #   --model GLCN \
# #   --hidden_dim 64 \
# #   --heads 1 \
# #   --drop_rate 0
  
# # #### GLCN_LPAT

# python -m node_classification.train_amazon \
#   --dataset Photo \
#   --model GLCN_LPAT \
#   --hidden_dim 64 \
#   --heads 1 \
#   --drop_rate 0

# # #### CFGAT

# # python -m node_classification.train_amazon \
# #   --dataset Photo \
# #   --model CFGAT \
# #   --hidden_dim 64 \
# #   --heads 1 \
# #   --drop_rate 0.3
  
# # #### CFGAT_LPAT

# python -m node_classification.train_amazon \
#   --dataset Photo \
#   --model CFGAT_LPAT \
#   --hidden_dim 64 \
#   --heads 1 \
#   --drop_rate 0.3

# # ### Amazon-Computers

# # #### GAT

# # python -m node_classification.train_amazon \
# #   --dataset Computers \
# #   --model GAT \
# #   --hidden_dim 64 \
# #   --heads 1 \
# #   --drop_rate 0.5
  
# # #### GAT+LPAT

# python -m node_classification.train_amazon \
#   --dataset Computers \
#   --model GAT_LPAT \
#   --hidden_dim 64 \
#   --heads 1 \
#   --drop_rate 0.5
  
# # #### GATv2

# # python -m node_classification.train_amazon \
# #   --dataset Computers \
# #   --model GATv2 \
# #   --hidden_dim 64 \
# #   --heads 1 \
# #   --drop_rate 0.5
  
# # #### GATv2+LPAT

# python -m node_classification.train_amazon \
#   --dataset Computers \
#   --model GATv2_LPAT \
#   --hidden_dim 64 \
#   --heads 1 \
#   --drop_rate 0.5
  
# # #### KAAGAT

# # python -m node_classification.train_amazon \
# #   --dataset Computers \
# #   --model KAAGAT \
# #   --hidden_dim 64 \
# #   --heads 1 \
# #   --drop_rate 0.5
  
# # #### KAAGAT+LPAT

# python -m node_classification.train_amazon \
#   --dataset Computers \
#   --model KAAGAT_LPAT \
#   --hidden_dim 64 \
#   --heads 1 \
#   --drop_rate 0.5

# # #### GLCN

# # python -m node_classification.train_amazon \
# #   --dataset Computers \
# #   --model GLCN \
# #   --hidden_dim 32 \
# #   --heads 1 \
# #   --drop_rate 0
  
# # #### GLCN+LPAT

# python -m node_classification.train_amazon \
#   --dataset Computers \
#   --model GLCN_LPAT \
#   --hidden_dim 32 \
#   --heads 1 \
#   --drop_rate 0

# # #### CFGAT

# # python -m node_classification.train_amazon \
# #   --dataset Computers \
# #   --model CFGAT \
# #   --hidden_dim 64 \
# #   --heads 1 \
# #   --drop_rate 0.1
  
# # #### CFGAT+LPAT

# python -m node_classification.train_amazon \
#   --dataset Computers \
#   --model CFGAT_LPAT \
#   --hidden_dim 64 \
#   --heads 1 \
#   --drop_rate 0.1

