import os
import sys
import gc
import argparse
import torch
import time
from torch.optim import Adam
import torch.nn as nn
import pandas as pd
from torch_geometric.nn import MessagePassing

from torch_geometric.datasets import ZINC
from torch_geometric.loader import DataLoader

from torch_geometric.nn import global_add_pool

from torch_geometric.nn import MLP
from thop import profile

# Get the four-level absolute path of current file (for modular calls)
current_dir = os.path.dirname(os.path.abspath(__file__))
project_root = os.path.dirname(os.path.dirname(os.path.dirname(current_dir)))
sys.path.insert(0, project_root)  # Insert at the beginning of path

# Import model modules
from model.GAT import GATConv
from model.GATv2 import GAT2Conv
from model.GLCN import GLCNConv
from model.CFGAT import CFGATConv
from model.KAA_GAT import KAAGATConv
from model.GAT_LPAT import GATLPATConv
from model.GATv2_LPAT import GAT2LPATConv
from model.GLCN_LPAT import GLCNLPATConv
from model.CFGAT_LPAT import CFGATLPATConv
from model.KAA_GAT_LPAT import KAAGATLPATConv


class EarlyStopper:
    """Early stopping utility to prevent overfitting"""
    
    def __init__(self, patience=1, min_delta=0):
        self.patience = patience
        self.min_delta = min_delta
        self.counter = 0
        self.min_validation_loss = float('inf')

    def early_stop(self, validation_loss):
        """Check if training should stop early"""
        if validation_loss < self.min_validation_loss:
            self.min_validation_loss = validation_loss
            self.counter = 0
        elif validation_loss >= (self.min_validation_loss + self.min_delta):
            self.counter += 1
            if self.counter >= self.patience:
                return True
        return False


def make_mlp(num_features, hidden_dim, out_dim, hidden_layers):
    """Create a Multi-Layer Perceptron with specified architecture"""
    if hidden_layers >= 2:
        list_hidden = [nn.Sequential(nn.Linear(num_features, hidden_dim), nn.ReLU())]
        for _ in range(hidden_layers - 2):
            list_hidden.append(nn.Sequential(nn.Linear(hidden_dim, hidden_dim), nn.ReLU()))
        list_hidden.append(nn.Linear(hidden_dim, out_dim))
    else:
        return nn.Sequential(nn.Linear(num_features, out_dim), nn.ReLU())
    MLP = nn.Sequential(*list_hidden)
    return MLP


def get_flops_per_graph(model, data):
    """Calculate average FLOPs per graph (corrected version)"""
    total_flops = 0
    total_params = sum(p.numel() for p in model.parameters() if p.requires_grad)
    
    # Get graph information
    num_graphs = data.num_graphs
    num_nodes = data.x.size(0)
    num_edges = data.edge_index.size(1)
    
    # Process embedding layer
    if model.embedding_layer:
        # Embedding layer FLOPs: num_nodes * embedding_dim * 2 (read/write operations)
        total_flops += num_nodes * 100 * 2
        current_dim = 100
    else:
        current_dim = data.x.size(1)
    
    # Process each graph convolution layer
    for i, conv in enumerate(model.conv):
        # Get layer output dimension
        out_dim = conv.out_channels
        
        # Calculate FLOPs based on different model types
        if isinstance(conv, (GATConv, GATLPATConv, GAT2Conv, GAT2LPATConv)):
            # GAT series model computational cost
            # Linear transformation: 2 * in_dim * out_dim * num_nodes
            total_flops += 2 * current_dim * out_dim * num_nodes
            # Attention calculation: 2 * out_dim * num_edges (feature combination per edge)
            total_flops += 2 * out_dim * num_edges
            # Attention coefficient calculation: 3 * num_edges (addition and exponent)
            total_flops += 3 * num_edges
            # Message aggregation: 2 * out_dim * num_edges (weighted summation)
            total_flops += 2 * out_dim * num_edges
            
        elif isinstance(conv, (GLCNConv, GLCNLPATConv)):
            # GLCN series model computational cost
            # Linear transformation
            total_flops += 2 * current_dim * out_dim * num_nodes
            # Similarity calculation: 3 * current_dim * num_edges (dot product and activation)
            total_flops += 3 * current_dim * num_edges
            # Message passing: 2 * out_dim * num_edges
            total_flops += 2 * out_dim * num_edges
            
        elif isinstance(conv, (CFGATConv, CFGATLPATConv)):
            # CFGAT series model computational cost
            # Two linear transformations
            total_flops += 2 * 2 * current_dim * out_dim * num_nodes
            # Cosine similarity calculation: 4 * out_dim * num_edges (normalization and dot product)
            total_flops += 4 * out_dim * num_edges
            # Attention coefficient calculation: 3 * num_edges
            total_flops += 3 * num_edges
            # Message aggregation: 2 * out_dim * num_edges
            total_flops += 2 * out_dim * num_edges
            
        elif isinstance(conv, (KAAGATConv, KAAGATLPATConv)):
            # KAA-GAT series model computational cost
            # Linear transformation
            total_flops += 2 * current_dim * out_dim * num_nodes
            # KAN layer extra computation
            if conv.kan_layers > 0:
                # KAN layer: 4 * current_dim * out_dim * num_nodes (interpolation and summation)
                total_flops += 4 * current_dim * out_dim * num_nodes
            # Attention calculation: 4 * out_dim * num_edges
            total_flops += 4 * out_dim * num_edges
            # Attention coefficient calculation: 3 * num_edges
            total_flops += 3 * num_edges
            # Message aggregation: 2 * out_dim * num_edges
            total_flops += 2 * out_dim * num_edges
            
        # For LPAT models, add feature scaling transformation FLOPs
        if 'LPAT' in type(conv).__name__:
            # Feature scaling transformation computational cost:
            # Mean and variance calculation: 3 * current_dim * num_nodes
            # Scaling factor calculation: 3 * current_dim * num_nodes (sigmoid)
            # Apply scaling: current_dim * num_nodes
            total_flops += (3 + 3 + 1) * current_dim * num_nodes
        
        # Update current dimension for next layer input dimension
        current_dim = out_dim
    
    # Global pooling layer FLOPs: 2 * num_nodes * current_dim
    total_flops += 2 * num_nodes * current_dim
    
    # MLP layer FLOPs
    for layer in model.mlp:
        if isinstance(layer, nn.Linear):
            in_mlp = layer.in_features
            out_mlp = layer.out_features
            # Fully connected layer FLOPs: 2 * in_mlp * out_mlp * num_graphs
            total_flops += 2 * in_mlp * out_mlp * num_graphs
        elif isinstance(layer, nn.ReLU):
            # ReLU activation: out_mlp * num_graphs
            total_flops += out_mlp * num_graphs
    
    # Calculate average FLOPs per graph
    flops_per_graph = total_flops
    return flops_per_graph, total_params


def get_model_info(model, data):
    """Function to get model FLOPs and parameter count"""
    try:
        flops_per_graph, total_params = get_flops_per_graph(model, data)
        return flops_per_graph, total_params
    except Exception as e:
        print(f"Error calculating FLOPs: {e}")
        return 0, 0  # Return default values to avoid crash


class Model(nn.Module):
    """Graph Neural Network Model with various convolution types for ZINC dataset"""
    
    def __init__(self, gnn_layers, num_features, hidden_dim, hidden_layers, grid_size, spline_order, n_targets, dropout,
                 embedding_layer=False):
        super(Model, self).__init__()
        kind = args.model
        if kind.endswith('LPAT'):
            # Define initial values for LPAT parameters
            omega_init = 1.0
            lambda_init = 5.0
            
        self.n_layers = gnn_layers
        self.embedding_layer = embedding_layer
        lst = list()

        # Model type selection and layer construction
        if args.model == 'GAT':
            if embedding_layer:
                self.node_emb = nn.Embedding(num_features, 100)
                lst.append(GATConv(100, hidden_dim, heads=1))
            else:
                lst.append(GATConv(num_features, hidden_dim, heads=1))
            for i in range(gnn_layers - 1):
                lst.append(GATConv(hidden_dim, hidden_dim, heads=1))
        elif args.model == 'GAT_LPAT':
            if embedding_layer:
                self.node_emb = nn.Embedding(num_features, 100)
                lst.append(GATLPATConv(100, hidden_dim, heads=1, omega_init=0.0, lambda_init=0.0))
            else:
                lst.append(GATLPATConv(num_features, hidden_dim, heads=1, omega_init=0.0, lambda_init=0.0))
            for i in range(gnn_layers - 1):
                lst.append(GATLPATConv(hidden_dim, hidden_dim, heads=1, omega_init=omega_init, lambda_init=lambda_init))
        elif args.model == 'GATv2':
            if embedding_layer:
                self.node_emb = nn.Embedding(num_features, 100)
                lst.append(GAT2Conv(100, hidden_dim, heads=1))
            else:
                lst.append(GAT2Conv(num_features, hidden_dim, heads=1))
            for i in range(gnn_layers - 1):
                lst.append(GAT2Conv(hidden_dim, hidden_dim, heads=1))
        elif args.model == 'GATv2_LPAT':
            if embedding_layer:
                self.node_emb = nn.Embedding(num_features, 100)
                lst.append(GAT2LPATConv(100, hidden_dim, heads=1, omega_init=0.0, lambda_init=0.0))
            else:
                lst.append(GAT2LPATConv(num_features, hidden_dim, heads=1, omega_init=0.0, lambda_init=0.0))
            for i in range(gnn_layers - 1):
                lst.append(GAT2LPATConv(hidden_dim, hidden_dim, heads=1, omega_init=omega_init, lambda_init=lambda_init))
        elif args.model == 'GLCN':
            if embedding_layer:
                self.node_emb = nn.Embedding(num_features, 100)
                lst.append(GLCNConv(100, hidden_dim, heads=1))
            else:
                lst.append(GLCNConv(num_features, hidden_dim, heads=1))
            for i in range(gnn_layers - 1):
                lst.append(GLCNConv(hidden_dim, hidden_dim, heads=1))
        elif args.model == 'GLCN_LPAT':
            if embedding_layer:
                self.node_emb = nn.Embedding(num_features, 100)
                lst.append(GLCNLPATConv(100, hidden_dim, heads=1, omega_init=0.0, lambda_init=0.0))
            else:
                lst.append(GLCNLPATConv(num_features, hidden_dim, heads=1, omega_init=0.0, lambda_init=0.0))
            for i in range(gnn_layers - 1):
                lst.append(GLCNLPATConv(hidden_dim, hidden_dim, heads=1, omega_init=omega_init, lambda_init=lambda_init))
        elif args.model == 'CFGAT':
            if embedding_layer:
                self.node_emb = nn.Embedding(num_features, 100)
                lst.append(CFGATConv(100, hidden_dim, heads=1))
            else:
                lst.append(CFGATConv(num_features, hidden_dim, heads=1))
            for i in range(gnn_layers - 1):
                lst.append(CFGATConv(hidden_dim, hidden_dim, heads=1))
        elif args.model == 'CFGAT_LPAT':
            if embedding_layer:
                self.node_emb = nn.Embedding(num_features, 100)
                lst.append(CFGATLPATConv(100, hidden_dim, heads=1, omega_init=0.0, lambda_init=0.0))
            else:
                lst.append(CFGATLPATConv(num_features, hidden_dim, heads=1, omega_init=0.0, lambda_init=0.0))
            for i in range(gnn_layers - 1):
                lst.append(CFGATLPATConv(hidden_dim, hidden_dim, heads=1, omega_init=omega_init, lambda_init=lambda_init))
        elif args.model == 'KAAGAT':
            if embedding_layer:
                self.node_emb = nn.Embedding(num_features, 100)
                lst.append(KAAGATConv(100, hidden_dim, heads=1, kan_layers=hidden_layers, grid_size=grid_size,
                                      spline_order=spline_order))
            else:
                lst.append(KAAGATConv(num_features, hidden_dim, heads=1, kan_layers=hidden_layers, grid_size=grid_size,
                                      spline_order=spline_order))
            for i in range(gnn_layers - 1):
                lst.append(KAAGATConv(hidden_dim, hidden_dim, heads=1, kan_layers=hidden_layers, grid_size=grid_size,
                                      spline_order=spline_order))
        elif args.model == 'KAAGAT_LPAT':
            if embedding_layer:
                self.node_emb = nn.Embedding(num_features, 100)
                lst.append(KAAGATLPATConv(100, hidden_dim, heads=1, kan_layers=hidden_layers, grid_size=grid_size,
                                      spline_order=spline_order, omega_init=0.0, lambda_init=0.0))
            else:
                lst.append(KAAGATLPATConv(num_features, hidden_dim, heads=1, kan_layers=hidden_layers, grid_size=grid_size,
                                      spline_order=spline_order, omega_init=0.0, lambda_init=0.0))
            for i in range(gnn_layers - 1):
                lst.append(KAAGATLPATConv(hidden_dim, hidden_dim, heads=1, kan_layers=hidden_layers, grid_size=grid_size,
                                      spline_order=spline_order, omega_init=omega_init, lambda_init=lambda_init))
       
        self.conv = nn.ModuleList(lst)
        self.mlp = make_mlp(hidden_dim, 64, n_targets, 2)
        self.dropout = nn.Dropout(dropout)
        self.relu = nn.ReLU()
        
    def reset_parameters(self):
        """Reset model parameters"""
        for conv in self.conv:
            conv.reset_parameters()

    def forward(self, data):
        """Forward pass through the model"""
        x, edge_index = data.x, data.edge_index
        if self.embedding_layer:
            x = self.node_emb(x).squeeze()
        for i in range(self.n_layers):
            x = self.conv[i](x, edge_index)
            x = self.dropout(x)

        x = global_add_pool(x, data.batch)
        x = self.mlp(x)
        return x


# Argument parser configuration
parser = argparse.ArgumentParser()
parser.add_argument('--batch-size', type=int, default=128, help='Input batch size for training')
parser.add_argument('--epochs', type=int, default=300, help='Number of epochs to train')
parser.add_argument('--model', type=str, default='GAT', help='GAT or KAAGAT')
parser.add_argument('--dropout', type=float, default=0.0, help='Dropout rate (1 - keep probability)')
parser.add_argument('--patience', type=int, default=20, help='Patience for early stopping')
parser.add_argument('--n-gnn-layers', type=int, default=4, help='Number of message passing layers')
parser.add_argument('--device_num', type=int, default=0, help='GPU device number')
parser.add_argument('--seed', type=int, default=1, help='Random seed')

args = parser.parse_args()

# Set random seed for reproducibility
random_seed = args.seed
torch.manual_seed(random_seed)
torch.cuda.manual_seed(random_seed)
torch.backends.cudnn.benchmark = False
torch.backends.cudnn.deterministic = True

# Device configuration
device = torch.device(f'cuda:{args.device_num}' if torch.cuda.is_available() else 'cpu')

# Dataset loading
train_dataset = ZINC('./dataset/ZINC', subset=True, split='train')
val_dataset = ZINC('./dataset/ZINC', subset=True, split='val')
test_dataset = ZINC('./dataset/ZINC', subset=True, split='test')

# Data loaders
train_loader = DataLoader(train_dataset, args.batch_size, shuffle=True)
val_loader = DataLoader(val_dataset, args.batch_size, shuffle=False)
test_loader = DataLoader(test_dataset, args.batch_size, shuffle=False)

# Hyperparameter search space
LR = [0.001]
HIDDEN_DIM = [128]

if args.model == 'KAAGAT' or args.model == 'KAAGAT_LPAT':
    N_LAYERS = [2, 3, 4]
    GRID_SIZE = [1, 2, 4]
    SPLINE_ORDER = [1, 2, 3]
else:
    N_LAYERS = [1]
    GRID_SIZE = [1]
    SPLINE_ORDER = [1]

# Hyperparameter search
best_val_mae = float('inf')
for lr in LR:
    for hidden_dim in HIDDEN_DIM:
        for n_layers in N_LAYERS:
            for grid_size in GRID_SIZE:
                for spline_order in SPLINE_ORDER:
                    print('Evaluating the following hyperparameters:')
                    print('lr:', lr, 'hidden_dim:', hidden_dim, 'n_layers:', n_layers, 'grid_size:', grid_size,
                          'spline_order:', spline_order)
                    model = Model(args.n_gnn_layers, 21, hidden_dim, n_layers, grid_size, spline_order, 1, args.dropout,
                                  True).to(device)
                    optimizer = Adam(model.parameters(), lr=lr)


                    def train(epoch):
                        """Training function for one epoch"""
                        model.train()

                        total_loss = 0
                        for data in train_loader:
                            data = data.to(device)
                            optimizer.zero_grad()
                            loss = (model(data).squeeze() - data.y).abs().mean()
                            loss.backward()
                            total_loss += loss.item() * data.num_graphs
                            optimizer.step()
                        return total_loss / len(train_loader.dataset)


                    @torch.no_grad()
                    def test(loader):
                        """Testing function"""
                        model.eval()

                        total_error = 0
                        for data in loader:
                            data = data.to(device)
                            total_error += (model(data).squeeze() - data.y).abs().sum().item()
                        return total_error / len(loader.dataset)


                    early_stopper = EarlyStopper(patience=args.patience)
                    for epoch in range(1, args.epochs + 1):
                        loss = train(epoch)
                        val_mae = test(val_loader)

                        if val_mae < best_val_mae:
                            best_val_mae = val_mae
                            best_hyperparams = {'lr': lr, 'hidden_dim': hidden_dim, 'n_layers': n_layers,
                                                'grid_size': grid_size, 'spline_order': spline_order}
                            print(f'Epoch: {epoch:03d}, Loss: {loss:.4f}, Val: {val_mae:.4f}')

                        if early_stopper.early_stop(val_mae):
                            print(f"Stopped at epoch {epoch}")
                            break

print('Best hyperparameters:')
print('lr:', best_hyperparams['lr'])
print('hidden_dim:', best_hyperparams['hidden_dim'])
print('n_layers:', best_hyperparams['n_layers'])
print('grid_size:', best_hyperparams['grid_size'])
print('spline_order:', best_hyperparams['spline_order'])

# Final evaluation with best hyperparameters
val_maes = []
test_maes = []
all_epoch_times = []  # Store all epoch times

for run in range(1):
    # Reset random seed (ensure reproducibility)
    torch.manual_seed(args.seed + run)
    if torch.cuda.is_available():
        torch.cuda.manual_seed_all(args.seed + run)
    print()
    print(f'Run {run}:')
    print()
    gc.collect()
    model = Model(args.n_gnn_layers, 21, best_hyperparams['hidden_dim'], best_hyperparams['n_layers'],
                  best_hyperparams['grid_size'], best_hyperparams['spline_order'], 1, args.dropout, True).to(device)
    total_params = sum(p.numel() for p in model.parameters())
    print('Number of parameters:', total_params)
    print(f"Parameter details:")
    for name, param in model.named_parameters():
        print(f"{name}: {param.numel()} params")
    
    # Calculate parameter count and FLOPs (only in first run)
    if run == 0:
        data_sample = next(iter(train_loader)).to(device)
        model_flops, _ = get_model_info(model, data_sample)
        model_flops = model_flops / 1e6  # Convert to MFLOPs
        print(f'Model FLOPs: {model_flops:.2f} M')
    else:
        # Clear cache to ensure accurate time measurement
        torch.cuda.empty_cache()
    
    optimizer = Adam(model.parameters(), lr=best_hyperparams['lr'])


    def train(epoch):
        """Training function for one epoch"""
        model.train()

        total_loss = 0
        for data in train_loader:
            data = data.to(device)
            optimizer.zero_grad()
            loss = (model(data).squeeze() - data.y).abs().mean()
            loss.backward()
            total_loss += loss.item() * data.num_graphs
            optimizer.step()
        return total_loss / len(train_loader.dataset)


    @torch.no_grad()
    def test(loader):
        """Testing function"""
        model.eval()

        total_error = 0
        for data in loader:
            data = data.to(device)
            total_error += (model(data).squeeze() - data.y).abs().sum().item()
        return total_error / len(loader.dataset)


    best_val_mae = test_mae = float('inf')
    early_stopper = EarlyStopper(patience=args.patience)
    epoch_times = []  # Store current run epoch times
    
    for epoch in range(1, args.epochs + 1):
        start_time = time.time()
        loss = train(epoch)
        epoch_time = time.time() - start_time
        epoch_times.append(epoch_time)
        
        val_mae = test(val_loader)

        if val_mae < best_val_mae:
            best_val_mae = val_mae
            test_mae = test(test_loader)
            print(f'Epoch: {epoch:03d}, Loss: {loss:.4f}, '
                  f'Val: {val_mae:.4f}, Test: {test_mae:.4f}, Time: {epoch_time:.2f}s')

        if early_stopper.early_stop(val_mae):
            print(f"Stopped at epoch {epoch}")
            break

    test_maes.append(test_mae)
    val_maes.append(best_val_mae)
    all_epoch_times.extend(epoch_times)  # Add current run epoch times to total list

# Calculate average epoch time
avg_epoch_time = sum(all_epoch_times) / len(all_epoch_times) if all_epoch_times else 0
print(f'Average epoch time: {avg_epoch_time:.4f} seconds')

test_mae = torch.tensor(test_maes)
print('===========================')
print(f'Final Test: {test_mae.mean():.4f} ± {test_mae.std():.4f}')

# Results collection
result_statistic = pd.DataFrame(
    columns=['Dataset', 'Model', 'mae', 'std'])

# Save results to file
with open('zinc_results.txt', 'a') as f: 
    f.write(f"Model:{args.model}, MAE:{test_mae.mean():.4f}±{test_mae.std():.4f}, Params:{total_params:.4f}, Flops:{model_flops:.2f}, Time:{avg_epoch_time:.4f}\n")