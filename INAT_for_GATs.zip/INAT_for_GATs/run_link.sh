#!/bin/bash

BASE_DIR=$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)
cd $BASE_DIR

export PYTHONPATH="$BASE_DIR:$PYTHONPATH"

## Link Prediction

### Cora

# #### GT

# python -m link_prediction.gt_train \
#   --dataset Cora \
#   --hidden_dim 128 \
#   --model GT \
#   --heads 1 \
#   --epoch_num 500 \
#   --lr 0.0001 \
#   --train_round 10 \
#   --pos_enc_dim 128 \
#   --layers 2 \
#   --in_feat_dropout 0.1 \
#   --dropout 0
  
# #### GT+LPAT

# python -m link_prediction.gt_train \
#   --dataset Cora \
#   --hidden_dim 128 \
#   --model GT_LPAT \
#   --heads 1 \
#   --epoch_num 500 \
#   --lr 0.0001 \
#   --train_round 10 \
#   --pos_enc_dim 128 \
#   --layers 2 \
#   --in_feat_dropout 0.1 \
#   --dropout 0

#### HeteGAT

# python -m link_prediction.HeteGAT_train \
#   --dataset Cora \
#   --model HeteGAT \
#   --hidden_dim 128 \
#   --heads 1 \
#   --drop_rate 0.5
  
#### HeteGAT_LPAT

# python -m link_prediction.HeteGAT_train \
#   --dataset Cora \
#   --model HeteGAT_LPAT \
#   --hidden_dim 128 \
#   --heads 1 \
#   --drop_rate 0.5

#### HLGAT

# python -m link_prediction.HLGAT_train \
#   --dataset Cora \
#   --model HLGAT \
#   --hidden_dim 128 \
#   --epoch_num 1000 \
#   --drop_rate 0.3
  
# #### HLGAT_LPAT

# python -m link_prediction.HLGAT_train \
#   --dataset Cora \
#   --model HLGAT_LPAT \
#   --hidden_dim 128 \
#   --epoch_num 1000 \
  # --drop_rate 0.3

#### GAT

python -m link_prediction.train \
  --dataset Cora \
  --model GAT \
  --hidden_dim 128 \
  --heads 1 \
  --drop_rate 0.5
  
### GAT+LPAT

python -m link_prediction.train \
  --dataset Cora \
  --model GAT_LPAT \
  --hidden_dim 128 \
  --heads 1 \
  --drop_rate 0.5
  
#### GATv2

python -m link_prediction.train \
  --dataset Cora \
  --model GATv2 \
  --hidden_dim 128 \
  --heads 1 \
  --drop_rate 0.5
  
#### GATv2+LPAT

python -m link_prediction.train \
  --dataset Cora \
  --model GATv2_LPAT \
  --hidden_dim 128 \
  --heads 1 \
  --drop_rate 0.5

#### KAAGAT

python -m link_prediction.train \
  --dataset Cora \
  --model KAAGAT \
  --hidden_dim 128 \
  --heads 1 \
  --kan_layers 2 \
  --grid_size 1 \
  --spline_order 1 \
  --drop_rate 0.5
  
#### KAAGAT+LPAT

python -m link_prediction.train \
  --dataset Cora \
  --model KAAGAT_LPAT \
  --hidden_dim 128 \
  --heads 1 \
  --kan_layers 2 \
  --grid_size 1 \
  --spline_order 1 \
  --drop_rate 0.5

#### GLCN

python -m link_prediction.train \
  --dataset Cora \
  --model GLCN \
  --hidden_dim 128 \
  --heads 1 \
  --drop_rate 0.5
  
#### GLCN+LPAT

python -m link_prediction.train \
  --dataset Cora \
  --model GLCN_LPAT \
  --hidden_dim 128 \
  --heads 1 \
  --drop_rate 0.5

### CFGAT

python -m link_prediction.train \
  --dataset Cora \
  --model CFGAT \
  --hidden_dim 128 \
  --heads 2 \
  --drop_rate 0.5
  
#### CFGAT+LPAT

python -m link_prediction.train \
  --dataset Cora \
  --model CFGAT_LPAT \
  --hidden_dim 128 \
  --heads 2 \
  --drop_rate 0.5
