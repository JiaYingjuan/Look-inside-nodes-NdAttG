import os
import sys
import torch
import argparse
import numpy as np
import torch.nn.functional as F
from sklearn.metrics import roc_auc_score

from torch_geometric.utils import negative_sampling
from torch_geometric.datasets import Planetoid
import torch_geometric.transforms as T

from torch import nn
import time
from thop import profile
from torch_geometric.nn.conv import MessagePassing

# Get the absolute path of current file
current_dir = os.path.dirname(os.path.abspath(__file__))
project_root = os.path.dirname(os.path.dirname(os.path.dirname(current_dir)))
sys.path.insert(0, project_root)
from model.HAN.HeteGAT import HeteGAT  # Import HeteGAT model
from model.HAN.HeteGAT_LPAT import HeteGAT_LPAT  # Import HeteGAT_LPAT model

# Argument parser configuration
parser = argparse.ArgumentParser(description='HeteGAT Link Prediction Training')

# HeteGAT specific parameters
parser.add_argument('--model', type=str, default='HeteGAT', help='Model type to use')
parser.add_argument('--hidden_dim', type=int, default=128, help='Hidden dimension size')
parser.add_argument('--heads', type=int, default=1, help='Number of attention heads')
parser.add_argument('--num_layer', type=int, default=2, help='Number of model layers')
parser.add_argument('--att_size', type=int, default=128, help='Relation attention size')

# General training parameters
parser.add_argument('--device_num', type=int, default=0, help='GPU device number')
parser.add_argument('--epoch_num', type=int, default=300, help='Number of training epochs')
parser.add_argument('--lr', type=float, default=0.01, help='Learning rate')
parser.add_argument('--drop_rate', type=float, default=0.0, help='Dropout rate')
parser.add_argument('--seed', type=int, default=1, help='Random seed')
parser.add_argument('--dataset', type=str, default='Cora', help='Dataset to test')
parser.add_argument('--train_round', type=int, default=10, help='Number of training rounds')

# Multi-relation settings
parser.add_argument('--num_relations', type=int, default=3, help='Number of relations in the graph')

args = parser.parse_args()

# Random seed setting
random_seed = args.seed
torch.manual_seed(random_seed)
if torch.cuda.is_available():
    torch.cuda.manual_seed(random_seed)
    torch.cuda.manual_seed_all(random_seed)
torch.backends.cudnn.benchmark = False
torch.backends.cudnn.deterministic = True

# Device selection
device = torch.device(f'cuda:{args.device_num}' if torch.cuda.is_available() else 'cpu')

# Load dataset and split
transform = T.Compose([
    T.NormalizeFeatures(),
    T.ToDevice(device),
    T.RandomLinkSplit(num_val=0.05, num_test=0.1, is_undirected=True,
                      add_negative_train_samples=False),
])
dataset = Planetoid(root="./dataset/", name=args.dataset, transform=transform)
train_data, val_data, test_data = dataset[0]


def build_heterogeneous_relations(data, num_relations=3):
    """Build multi-relation graph data"""
    edge_index = data.edge_index
    num_nodes = data.num_nodes
    
    relation_edge_indices = []
    
    # Relation 1: Original relation
    relation_edge_indices.append(edge_index)
    
    # Relation 2: Reverse relation
    reverse_edge_index = torch.stack([edge_index[1], edge_index[0]], dim=0)
    relation_edge_indices.append(reverse_edge_index)
    
    # Relation 3: Self-loop relation
    self_loop = torch.arange(num_nodes).repeat(2, 1).to(edge_index.device)
    relation_edge_indices.append(self_loop)
    
    # If more relations are needed, generate randomly
    for i in range(3, num_relations):
        num_edges = edge_index.size(1)
        sample_size = int(num_edges * 0.7)
        indices = torch.randperm(num_edges)[:sample_size]
        sampled_edges = edge_index[:, indices]
        relation_edge_indices.append(sampled_edges)
    
    return relation_edge_indices


# Build multi-relation graph for training data
train_relation_edge_indices = build_heterogeneous_relations(train_data, args.num_relations)


class HeteGATLinkPrediction(nn.Module):
    """HeteGAT Model for Link Prediction Task"""
    
    def __init__(self, in_channels, hidden_channels, out_channels, heads,
                 num_relations, num_layers=2, att_size=128, dropout=0.0, 
                 residual=False):
        super().__init__()
        # HeteGAT encoder
        self.encoder = HeteGAT(
            in_channels=in_channels,
            hidden_channels=hidden_channels,
            out_channels=out_channels,  # Output node embedding dimension
            heads=heads,
            num_relations=num_relations,
            num_layers=num_layers,
            att_size=att_size,
            dropout=dropout,
            residual=residual,
            return_attention=False
        )
        
    def encode(self, x, relation_edge_indices):
        """Generate node embeddings"""
        return self.encoder(x, relation_edge_indices)
    
    def decode(self, z, edge_label_index):
        """Predict links using node embeddings"""
        src, dst = edge_label_index
        return (z[src] * z[dst]).sum(dim=-1)
    
    def forward(self, x, relation_edge_indices):
        """Forward pass"""
        return self.encode(x, relation_edge_indices)


class HeteGAT_LPAT_LinkPrediction(nn.Module):
    """HeteGAT LPAT Model for Link Prediction Task"""
    
    def __init__(self, in_channels, hidden_channels, out_channels, heads,
                 num_relations, num_layers=2, att_size=128, dropout=0.0, 
                 residual=False, omega_init=1.0, lambda_init=5.0):
        super().__init__()
        # HeteGAT_LPAT encoder
        self.encoder = HeteGAT_LPAT(
            in_channels=in_channels,
            hidden_channels=hidden_channels,
            out_channels=out_channels,  # Output node embedding dimension
            heads=heads,
            num_relations=num_relations,
            num_layers=num_layers,
            att_size=att_size,
            dropout=dropout,
            residual=residual,
            return_attention=False,
            omega_init=omega_init,
            lambda_init=lambda_init
        )
        
    def encode(self, x, relation_edge_indices):
        """Generate node embeddings"""
        return self.encoder(x, relation_edge_indices)
    
    def decode(self, z, edge_label_index):
        """Predict links using node embeddings"""
        src, dst = edge_label_index
        return (z[src] * z[dst]).sum(dim=-1)
    
    def forward(self, x, relation_edge_indices):
        """Forward pass"""
        return self.encode(x, relation_edge_indices)


# Create model
if args.model == 'HeteGAT':
    model = HeteGATLinkPrediction(
        in_channels=dataset.num_features,
        hidden_channels=args.hidden_dim,
        out_channels=64,  # Output dimension for link prediction
        heads=args.heads,
        num_relations=args.num_relations,
        num_layers=args.num_layer,
        att_size=args.att_size,
        dropout=args.drop_rate,
        residual=True
    ).to(device)
elif args.model == 'HeteGAT_LPAT':
    model = HeteGAT_LPAT_LinkPrediction(
        in_channels=dataset.num_features,
        hidden_channels=args.hidden_dim,
        out_channels=64,  # Output dimension for link prediction
        heads=args.heads,
        num_relations=args.num_relations,
        num_layers=args.num_layer,
        att_size=args.att_size,
        dropout=args.drop_rate,
        residual=True,
        omega_init=1.0,
        lambda_init=5.0
    ).to(device)

optimizer = torch.optim.Adam(model.parameters(), lr=args.lr)
criterion = torch.nn.BCEWithLogitsLoss()


def get_flops(model, x, relation_edge_indices):
    """Get FLOPs and parameter count for HeteGAT model"""
    # Count parameter number
    total_params = sum(p.numel() for p in model.parameters() if p.requires_grad)
    
    # Manual FLOPs estimation (avoid issues with thop.profile)
    num_nodes = x.size(0)
    num_edges = sum(edge_index.size(1) for edge_index in relation_edge_indices)
    
    flops = 0
    in_dim = x.size(1)
    hidden_dim = args.hidden_dim
    heads = args.heads
    num_layers = args.num_layer
    num_relations = args.num_relations
    att_size = args.att_size
    out_dim = 64  # Link prediction output dimension
    
    # Input transformation
    flops += num_nodes * in_dim * hidden_dim * heads
    
    # GAT layer computation
    for i in range(num_layers):
        # Computation for each relation per layer
        flops += num_relations * num_edges * hidden_dim * heads
        
        # If not the last layer, perform relation aggregation
        if i < num_layers - 1:
            flops += num_nodes * num_relations * hidden_dim * heads * att_size
            flops += num_nodes * num_relations * att_size  # Attention computation
    
    # Output layer
    flops += num_nodes * hidden_dim * heads * out_dim
    
    return flops, total_params


# Get FLOPs information
sample_x = train_data.x.float()
total_flops, total_params = get_flops(model, sample_x, train_relation_edge_indices)


def train():
    """Training function for one epoch"""
    model.train()
    optimizer.zero_grad()
    
    # Generate node embeddings
    z = model.encode(train_data.x, train_relation_edge_indices)
    
    # Negative sampling
    neg_edge_index = negative_sampling(
        edge_index=train_data.edge_index, 
        num_nodes=train_data.num_nodes,
        num_neg_samples=train_data.edge_label_index.size(1), 
        method='sparse'
    )
    
    # Combine positive and negative samples
    edge_label_index = torch.cat(
        [train_data.edge_label_index, neg_edge_index],
        dim=-1,
    )
    edge_label = torch.cat([
        train_data.edge_label,
        train_data.edge_label.new_zeros(neg_edge_index.size(1))
    ], dim=0)
    
    # Predict links
    out = model.decode(z, edge_label_index).view(-1)
    loss = criterion(out, edge_label)
    loss.backward()
    optimizer.step()
    return loss.item()


@torch.no_grad()
def test(data):
    """Testing function"""
    model.eval()
    # Use training data relation graph to generate node embeddings
    z = model.encode(train_data.x, train_relation_edge_indices)
    # Predict links
    out = model.decode(z, data.edge_label_index).view(-1).sigmoid()
    return roc_auc_score(data.edge_label.cpu().numpy(), out.cpu().numpy())


# Training loop
test_auc_list = []
time_list = []

for round_idx in range(args.train_round):
    # Reset random seed
    torch.manual_seed(args.seed + round_idx)
    if torch.cuda.is_available():
        torch.cuda.manual_seed_all(args.seed + round_idx)
    
    print(f'\n=== Round {round_idx+1}/{args.train_round} ===')
    start_time = time.time()
    best_val_auc = test_auc = 0
    
    # Reset model parameters
    for module in model.modules():
        if hasattr(module, 'reset_parameters'):
            module.reset_parameters()
    
    # Create new optimizer
    optimizer = torch.optim.Adam(model.parameters(), lr=args.lr)
    
    # Print parameter details
    print(f"Model parameters (round {round_idx+1}):")
    total_params = 0
    for name, param in model.named_parameters():
        if param.requires_grad:
            print(f"  {name}: {param.numel()} parameters")
            total_params += param.numel()
    print(f"Total trainable parameters: {total_params}")
    
    # Training loop
    for epoch in range(1, args.epoch_num + 1):
        epoch_start = time.time()
        
        # Training
        loss = train()
        
        # Validation
        val_auc = test(val_data)
        
        # Testing
        tmp_test_auc = test(test_data)
        
        # Update best results
        if val_auc > best_val_auc:
            best_val_auc = val_auc
            test_auc = tmp_test_auc
        
        epoch_time = time.time() - epoch_start
        print(f'Epoch {epoch:03d}: Loss={loss:.4f}, Val AUC={val_auc:.4f}, Test AUC={tmp_test_auc:.4f}, Time={epoch_time:.2f}s')
    
    # Record current round results
    test_auc_list.append(test_auc)
    round_time = time.time() - start_time
    time_list.append(round_time)
    print(f'Round {round_idx+1} completed. Test AUC: {test_auc:.4f}, Time: {round_time:.2f}s')

# Calculate average results
auc_avg = float(np.mean(test_auc_list))
auc_std = float(np.std(test_auc_list))
time_avg = float(np.mean(time_list))

print('\n' + '=' * 80)
print('Training completed.')
print(f'Dataset: {args.dataset}')
print(f'Average Test AUC: {auc_avg:.4f} ± {auc_std:.4f}')
print(f'Average Time per Round: {time_avg:.2f}s')
print(f'Model FLOPs: {total_flops/1e6:.2f}M')
print(f'Model Parameters: {total_params}')

# Save results to file
result_str = (f"Model: {args.model},"
             f"Dataset: {args.dataset},"
             f"Avg Test AUC: {auc_avg:.4f} ± {auc_std:.4f},"
             f"Avg Time: {time_avg:.2f}s,"
             f"FLOPs: {total_flops/1e6:.2f}M, Params: {total_params}\n")

# Write results to file
result_filename = f"link_results.txt"
with open(result_filename, 'a') as f:
    f.write(result_str)

print(f"Results saved to {result_filename}")