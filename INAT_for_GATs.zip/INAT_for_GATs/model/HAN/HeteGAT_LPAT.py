import torch
import torch.nn as nn
import torch.nn.functional as F
from .hetgat_LPAT_conv import HeteGAT_LPAT_Conv, RelationAggregator

class HeteGAT_LPAT(nn.Module):
    def __init__(self, in_channels, hidden_channels, out_channels, heads,
                 num_relations, num_layers=2, att_size=128, dropout=0.6, 
                 residual=False, return_attention=False, omega_init: float = 1.0, lambda_init: float = 5.0):
        super().__init__()
        self.num_relations = num_relations
        self.num_layers = num_layers
        self.return_attention = return_attention
        self.dropout = dropout
        
        # Create multiple GAT layers (one per relation per layer)
        self.convs = nn.ModuleList()
        for layer_idx in range(num_layers):
            layer_convs = nn.ModuleList()
            for _ in range(num_relations):
                # First layer has different input dimensions
                in_dim = in_channels if len(self.convs) == 0 else hidden_channels * heads
                out_dim = hidden_channels if len(self.convs) < num_layers - 1 else out_channels
                
                # # For Link_prediction, use 0.0 initialization for LPAT parameters in first layer, use passed values for other layers
                # if layer_idx == 0:
                #     conv_omega = 0.0
                #     conv_lambda = 0.0
                #     conv = HeteGAT_LPAT_Conv(
                #     in_dim, 
                #     out_dim,
                #     heads=heads,
                #     concat=True,
                #     dropout=dropout,
                #     residual=residual,
                #     omega_init=conv_omega,  # Use adjusted value
                #     lambda_init=conv_lambda  # Use adjusted value
                # )
                # else:
                #     conv = HeteGAT_LPAT_Conv(
                #     in_dim, 
                #     hidden_channels if len(self.convs) < num_layers - 1 else out_channels,
                #     heads=heads,
                #     concat=True,
                #     dropout=dropout,
                #     residual=residual,
                #     omega_init=omega_init,  # Pass LPAT parameters
                #     lambda_init=lambda_init  # Pass LPAT parameters
                # )
                
                conv = HeteGAT_LPAT_Conv(
                    in_dim, 
                    hidden_channels if len(self.convs) < num_layers - 1 else out_channels,
                    heads=heads,
                    concat=True,
                    dropout=dropout,
                    residual=residual,
                    omega_init=omega_init,  # Pass LPAT parameters
                    lambda_init=lambda_init  # Pass LPAT parameters
                )
                layer_convs.append(conv)
            self.convs.append(layer_convs)
        
        # Relation aggregation layers
        self.relation_aggregators = nn.ModuleList()
        for i in range(num_layers - 1):
            agg = RelationAggregator(
                hidden_channels * heads, 
                att_size=att_size,
                omega_init=omega_init,  # Pass LPAT parameters
                lambda_init=lambda_init  # Pass LPAT parameters
            )
            self.relation_aggregators.append(agg)
        
        # Final output aggregation
        self.final_aggregator = RelationAggregator(
            out_channels * heads, 
            att_size=att_size,
            omega_init=omega_init,  # Pass LPAT parameters
            lambda_init=lambda_init  # Pass LPAT parameters
        )
        
    def reset_parameters(self):
        """Reset parameters of all modules"""
        # Reset convolutional layer parameters
        for layer_convs in self.convs:
            for conv in layer_convs:
                conv.reset_parameters()
        
        # Reset relation aggregator parameters
        for aggregator in self.relation_aggregators:
            aggregator.reset_parameters()
        
        # Reset final aggregator parameters
        self.final_aggregator.reset_parameters()

    def forward(self, x, relation_edge_indices):
        # x: node features [N, in_channels]
        # relation_edge_indices: relation indices list [R elements of (N, 2)]
        
        attentions = []
        for layer_idx in range(self.num_layers):
            layer_embeddings = []
            layer_attentions = []
            
            # Apply GAT for each relation
            for rel_idx in range(self.num_relations):
                conv = self.convs[layer_idx][rel_idx]
                edge_index = relation_edge_indices[rel_idx]
                
                # First layer uses original features, subsequent layers use aggregated features
                if layer_idx == 0:
                    input_x = x
                else:
                    input_x = aggregated
                
                # Apply GAT convolution
                out, att = conv(input_x, edge_index, return_attention_weights=True)
                
                layer_embeddings.append(out)
                layer_attentions.append(att)
            
            # Save attention weights
            if self.return_attention:
                attentions.append(layer_attentions)
            
            # Stack results from all relations [N, R, C]
            embeddings_tensor = torch.stack(layer_embeddings, dim=1)
            
            # If not the last layer, perform relation aggregation
            if layer_idx < self.num_layers - 1:
                aggregated, rel_alpha = self.relation_aggregators[layer_idx](
                    embeddings_tensor, return_attention=True
                )
                aggregated = F.elu(aggregated)
                aggregated = F.dropout(aggregated, p=self.dropout, training=self.training)
                
                if self.return_attention:
                    attentions[-1].append(rel_alpha)  # Add relation-level attention
            else:
                # Final layer aggregation
                aggregated, rel_alpha = self.final_aggregator(
                    embeddings_tensor, return_attention=True
                )
                if self.return_attention:
                    attentions.append([rel_alpha])
        
        if self.return_attention:
            return aggregated, attentions
        return aggregated