#!/bin/bash

BASE_DIR=$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)
cd $BASE_DIR

export PYTHONPATH="$BASE_DIR:$PYTHONPATH"

# #### Cora

#### HeteGAT

# python -m node_classification.HeteGAT_train \
#   --dataset Cora \
#   --model HeteGAT \
#   --heads 8 \
#   --hidden_dim 8 \
#   --drop_rate 0.6 \
#   --device_num 0 \
#   --epoch_num 500 \
#   --lr 0.005 \
#   --train_round 10 \
#   --file_id 0

#### HeteGAT+LPAT

# python -m node_classification.HeteGAT_train \
#   --dataset Cora \
#   --model HeteGAT_LPAT \
#   --heads 8 \
#   --hidden_dim 8 \
#   --drop_rate 0.6 \
#   --device_num 0 \
#   --epoch_num 500 \
#   --lr 0.005 \
#   --train_round 10 \
#   --file_id 0

#### GT

# python -m node_classification.gt_train \
#   --model GT \
#   --dataset Cora \
#   --num_heads 1 \
#   --num_layers 2 \
#   --pos_enc_dim 128 \
#   --train_round 10 \
#   --lr 0.005 \
#   --wd 5e-4 \
#   --epoch 300 \
#   --hidden_dim 128 \
#   --in_feat_dropout 0.2 \
#   --drop_rate 0.8

#### GT+LPAT

# python -m node_classification.gt_train \
#   --model GT_LPAT \
#   --dataset Cora \
#   --num_heads 1 \
#   --num_layers 2 \
#   --pos_enc_dim 128 \
#   --train_round 10 \
#   --lr 0.005 \
#   --wd 5e-4 \
#   --epoch 300 \
#   --hidden_dim 128 \
#   --in_feat_dropout 0.2 \
#   --drop_rate 0.8



# #### HLGAT

# python -m node_classification.HLGAT_train \
#   --dataset Cora \
#   --model HLGAT \
#   --hidden_dim 64 \
#   --drop_rate 0.6 \
#   --device_num 0 \
#   --epoch_num 300 \
#   --lr 0.005 \
#   --train_round 1 \
#   --p_l 0.1 \
#   --p_h 0.5 \
#   --eps 0.8 
  
# #### HLGAT_LPAT

# python -m node_classification.HLGAT_train \
#   --dataset Cora \
#   --model HLGAT_LPAT \
#   --hidden_dim 64 \
#   --drop_rate 0.6 \
#   --device_num 0 \
#   --epoch_num 300 \
#   --lr 0.005 \
#   --train_round 1 \
#   --p_l 0.1 \
#   --p_h 0.5 \
#   --eps 0.8 

#### GAT

python -m node_classification.train \
  --dataset Cora \
  --model GAT \
  --hidden_dim 8 \
  --drop_rate 0.8 \
  --device_num 0 \
  --epoch_num 300 \
  --lr 0.005 \
  --file_id 0

#### GAT+LPAT

python -m node_classification.train \
  --dataset Cora \
  --model GAT_LPAT \
  --hidden_dim 8 \
  --drop_rate 0.8 \
  --device_num 0 \
  --epoch_num 300 \
  --lr 0.005 \
  --file_id 0

#### GATv2

python -m node_classification.train \
  --dataset Cora \
  --model GATv2 \
  --hidden_dim 8 \
  --drop_rate 0.8 \
  --device_num 0 \
  --epoch_num 300 \
  --lr 0.005 \
  --file_id 0
  
### GATv2+LPAT

python -m node_classification.train \
  --dataset Cora \
  --model GATv2_LPAT \
  --hidden_dim 8 \
  --drop_rate 0.8 \
  --device_num 0 \
  --epoch_num 300 \
  --lr 0.005 \
  --file_id 0

#### KAAGAT
  
python -m node_classification.train \
  --dataset Cora \
  --model KAAGAT \
  --hidden_dim 8 \
  --kan_layers 3 \
  --grid_size 1 \
  --spline_order 2 \
  --drop_rate 0.8 \
  --device_num 0 \
  --epoch_num 300 \
  --lr 0.005 \
  --file_id 0
  
#### KAAGAT+LPAT
  
python -m node_classification.train \
  --dataset Cora \
  --model KAAGAT_LPAT \
  --hidden_dim 8 \
  --kan_layers 3 \
  --grid_size 1 \
  --spline_order 2 \
  --drop_rate 0.8 \
  --device_num 0 \
  --epoch_num 300 \
  --lr 0.005 \
  --file_id 0

#### GLCN

python -m node_classification.train \
  --dataset Cora \
  --model GLCN \
  --hidden_dim 8 \
  --drop_rate 0.8 \
  --device_num 0 \
  --epoch_num 300 \
  --lr 0.005 \
  --file_id 0
  
# #### GLCN+LPAT

python -m node_classification.train \
  --dataset Cora \
  --model GLCN_LPAT \
  --hidden_dim 8 \
  --drop_rate 0.8 \
  --device_num 0 \
  --epoch_num 300 \
  --lr 0.005 \
  --file_id 0

#### CFGAT

python -m node_classification.train \
  --dataset Cora \
  --model CFGAT \
  --hidden_dim 8 \
  --drop_rate 0.8 \
  --device_num 0 \
  --epoch_num 300 \
  --lr 0.005 \
  --file_id 0
  
#### CFGAT+LPAT

python -m node_classification.train \
  --dataset Cora \
  --model CFGAT_LPAT \
  --hidden_dim 8 \
  --drop_rate 0.8 \
  --device_num 0 \
  --epoch_num 300 \
  --lr 0.005 \
  --file_id 0




