import torch
import typing
from typing import Union, Tuple, Optional, overload
from torch_geometric.nn.conv import MessagePassing
from torch_geometric.nn.dense.linear import Linear
from torch_geometric.typing import Adj, OptPairTensor, OptTensor, Size, SparseTensor
from torch_geometric.utils import add_self_loops, remove_self_loops, softmax
from torch import Tensor, nn
import torch.nn.functional as F
from torch.nn import Parameter
from torch_geometric.nn.inits import glorot, zeros


class GAT2Conv(MessagePassing):
    """GATv2 Convolution Layer with improved attention mechanism"""
    
    def __init__(
        self,
        in_channels: Union[int, Tuple[int, int]],
        out_channels: int,
        heads: int = 1,
        concat: bool = True,
        negative_slope: float = 0.2,
        dropout: float = 0.0,
        add_self_loops: bool = True,
        edge_dim: Optional[int] = None,
        fill_value: Union[float, Tensor, str] = 'mean',
        bias: bool = True,
        residual: bool = False,
        share_weights: bool = True,  # Added shared weights parameter
        **kwargs,
    ):
        kwargs.setdefault('aggr', 'add')
        super().__init__(node_dim=0, **kwargs)

        self.in_channels = in_channels
        self.out_channels = out_channels
        self.heads = heads
        self.concat = concat
        self.negative_slope = negative_slope
        self.dropout = dropout
        self.add_self_loops = add_self_loops
        self.edge_dim = edge_dim
        self.fill_value = fill_value
        self.residual = residual
        self.share_weights = share_weights  # Added shared weights logic

        # Linear transformation layer definitions
        if isinstance(in_channels, int):
            self.lin_src = Linear(in_channels, heads * out_channels, bias=False)
            self.lin_dst = self.lin_src if share_weights else Linear(in_channels, heads * out_channels, bias=False)
        else:
            self.lin_src = Linear(in_channels[0], heads * out_channels, bias=False)
            self.lin_dst = Linear(in_channels[1], heads * out_channels, bias=False)

        # Attention parameters
        self.att = Parameter(torch.Tensor(1, heads, out_channels))

        # Edge feature processing
        if edge_dim is not None:
            self.lin_edge = Linear(edge_dim, heads * out_channels, bias=False)
            self.att_edge = Parameter(torch.Tensor(1, heads, out_channels))
        else:
            self.lin_edge = None
            self.register_parameter('att_edge', None)

        # Residual connection
        if residual:
            self.res = Linear(
                in_channels if isinstance(in_channels, int) else in_channels[1],
                heads * out_channels if concat else out_channels,
                bias=False
            )
        else:
            self.register_parameter('res', None)

        # Bias term
        if bias:
            self.bias = Parameter(torch.Tensor(heads * out_channels if concat else out_channels))
        else:
            self.register_parameter('bias', None)

        self.reset_parameters()

    def reset_parameters(self):
        """Reset all learnable parameters of the module"""
        super().reset_parameters()
        self.lin_src.reset_parameters()
        if not self.share_weights:
            self.lin_dst.reset_parameters()
        if self.lin_edge is not None:
            self.lin_edge.reset_parameters()
        glorot(self.att)
        if self.att_edge is not None:
            glorot(self.att_edge)
        if self.res is not None:
            self.res.reset_parameters()
        zeros(self.bias)

    def forward(self, x: Union[Tensor, OptPairTensor], edge_index: Adj,
                edge_attr: OptTensor = None, size: Size = None,
                return_attention_weights: Optional[bool] = None):
        """Forward pass through the GATv2 layer"""

        H, C = self.heads, self.out_channels
        x_src = x_dst = None

        # Process input features
        if isinstance(x, Tensor):
            x_src = self.lin_src(x).view(-1, H, C)
            x_dst = self.lin_dst(x).view(-1, H, C) if not self.share_weights else x_src
        else:
            x_src = self.lin_src(x[0]).view(-1, H, C)
            x_dst = self.lin_dst(x[1]).view(-1, H, C) if x[1] is not None else x_src

        # Handle self-loops
        if self.add_self_loops:
            if isinstance(edge_index, Tensor):
                num_nodes = x_src.size(0)
                edge_index, edge_attr = remove_self_loops(edge_index, edge_attr)
                edge_index, edge_attr = add_self_loops(
                    edge_index, edge_attr, fill_value=self.fill_value,
                    num_nodes=num_nodes)
            elif isinstance(edge_index, SparseTensor):
                edge_index = set_diag(edge_index)

        # Attention calculation
        alpha = (x_src, x_dst)
        alpha = self.edge_updater(edge_index, alpha=alpha, edge_attr=edge_attr)

        # Message propagation
        out = self.propagate(edge_index, x=(x_src, x_dst), alpha=alpha, size=size)

        # Post-processing
        if self.concat:
            out = out.view(-1, self.heads * self.out_channels)
        else:
            out = out.mean(dim=1)

        # Residual connection
        if self.res is not None:
            res = self.res(x if isinstance(x, Tensor) else x[1])
            out += res

        if self.bias is not None:
            out += self.bias

        # Return attention weights
        if return_attention_weights:
            if isinstance(edge_index, Tensor):
                return out, (edge_index, alpha)
            elif isinstance(edge_index, SparseTensor):
                return out, edge_index.set_value(alpha, layout='coo')
        return out

    def edge_update(self, alpha_j: Tensor, alpha_i: Tensor, edge_attr: OptTensor,
                    index: Tensor, ptr: OptTensor, dim_size: Optional[int]) -> Tensor:
        """Compute edge attention coefficients for GATv2"""
        # Combine source and target node features
        x = alpha_j + alpha_i
        x = F.leaky_relu(x, self.negative_slope)
        alpha = (x * self.att).sum(dim=-1)

        # Edge feature processing
        if edge_attr is not None and self.lin_edge is not None:
            edge_attr = self.lin_edge(edge_attr).view(-1, self.heads, self.out_channels)
            alpha_edge = (edge_attr * self.att_edge).sum(dim=-1)
            alpha += alpha_edge

        # Normalize attention coefficients
        alpha = softmax(alpha, index, ptr, dim_size)
        alpha = F.dropout(alpha, p=self.dropout, training=self.training)
        return alpha

    def message(self, x_j: Tensor, alpha: Tensor) -> Tensor:
        """Message computation with attention weights"""
        return alpha.unsqueeze(-1) * x_j

    def __repr__(self) -> str:
        return (f'{self.__class__.__name__}({self.in_channels}, '
                f'{self.out_channels}, heads={self.heads})')