import os
import sys
import torch
import argparse
from torch_geometric.datasets import Planetoid
import numpy as np
import torch_geometric.transforms as T
import torch.nn.functional as F
from torch import nn

import time
from thop import profile, clever_format
from torch_geometric.nn.conv import MessagePassing

# sys.path.append(os.path.join(os.path.dirname("__file__"), '..'))
# Get the four-level absolute path of the current file (for modular calls)
current_dir = os.path.dirname(os.path.abspath(__file__))
project_root = os.path.dirname(os.path.dirname(os.path.dirname(current_dir)))
sys.path.insert(0, project_root)  # Insert at the beginning of the path
from model.GAT import GATConv
from model.GAT_LPAT import GATLPATConv
from model.GATv2 import GAT2Conv
from model.GATv2_LPAT import GAT2LPATConv
from model.GLCN import GLCNConv
from model.GLCN_LPAT import GLCNLPATConv
from model.CFGAT import CFGATConv
from model.CFGAT_LPAT import CFGATLPATConv
from model.KAA_GAT import KAAGATConv
from model.KAA_GAT_LPAT import KAAGATLPATConv

parser = argparse.ArgumentParser(description='PyTorch implementation of downstream adaptation.')

parser.add_argument('--model', type=str, default='KAACFGAT', help='the used model type')
parser.add_argument('--hidden_dim', type=int, default=8, help='the hidden dimension')
parser.add_argument('--heads', type=int, default=8, help='the head number')
parser.add_argument('--num_layer', type=int, default=2, help='the model layer number')

parser.add_argument('--device_num', type=int, default=0, help='the device number')
parser.add_argument('--epoch_num', type=int, default=300, help='the epoch number')
parser.add_argument('--lr', type=float, default=0.005, help='the learning rate')
parser.add_argument('--drop_rate', type=float, default=0.3, help='the dropping rate')

parser.add_argument('--kan_layers', type=int, default=0, help='the kan layer number')
parser.add_argument('--grid_size', type=int, default=1, help='the grid size of kan')
parser.add_argument('--spline_order', type=int, default=1, help='the spline order of kan')

parser.add_argument('--seed', type=int, default=1, help='the random seed')
parser.add_argument('--dataset', type=str, default='Cora', help='the test dataset')
parser.add_argument('--train_round', type=int, default=10, help='the train round number')
parser.add_argument('--file_id', type=int, default=0, help='the file id')

args = parser.parse_args()

# Random seed
random_seed = args.seed
torch.manual_seed(random_seed)
torch.cuda.manual_seed(random_seed)
torch.backends.cudnn.benchmark = False
torch.backends.cudnn.deterministic = True

# Device selection
device = torch.device('cuda:{}'.format(args.device_num) if torch.cuda.is_available() else 'cpu')


# Collect dataset
dataset = Planetoid(root="./dataset/", name=args.dataset,
                    transform=T.NormalizeFeatures())
data = dataset[0].to(device=device)

# Model
class Model(torch.nn.Module):
    def __init__(self, kind, input_dim, hidden_dim, output_dim, heads, drop_rate, kan_layers, grid_size, spline_order):
        super(Model, self).__init__()
        if kind.endswith('LPAT'):
            omega_init = 1.0
            lambda_init = 5.0
            
        if kind == 'GAT':
            self.conv1 = GATConv(input_dim, hidden_dim, heads=heads, dropout=drop_rate)
            self.conv2 = GATConv(hidden_dim * heads, output_dim, heads=1, dropout=drop_rate)
        elif kind == 'GAT_LPAT':
            self.conv1 = GATLPATConv(input_dim, hidden_dim, heads=heads, dropout=drop_rate, omega_init=0.0, lambda_init=10.0)
            self.conv2 = GATLPATConv(hidden_dim * heads, output_dim, heads=1, dropout=drop_rate, omega_init=0.0, lambda_init=0.0)
        elif kind == 'GATv2':
            self.conv1 = GAT2Conv(input_dim, hidden_dim, heads=heads, dropout=drop_rate)
            self.conv2 = GAT2Conv(hidden_dim * heads, output_dim, heads=1, dropout=drop_rate)
        elif kind == 'GATv2_LPAT':
            self.conv1 = GAT2LPATConv(input_dim, hidden_dim, heads=heads, dropout=drop_rate, omega_init=0.0, lambda_init=10.0)
            self.conv2 = GAT2LPATConv(hidden_dim * heads, output_dim, heads=1, dropout=drop_rate, omega_init=0.0, lambda_init=0.0)
        elif kind == 'GLCN':
            self.conv1 = GLCNConv(input_dim, hidden_dim, heads=heads, dropout=drop_rate)
            self.conv2 = GLCNConv(hidden_dim * heads, output_dim, heads=1, dropout=drop_rate)
        elif kind == 'GLCN_LPAT':
            self.conv1 = GLCNLPATConv(input_dim, hidden_dim, heads=heads, dropout=drop_rate, omega_init=0.0, lambda_init=0.0)
            self.conv2 = GLCNLPATConv(hidden_dim * heads, output_dim, heads=1, dropout=drop_rate, omega_init=omega_init, lambda_init=lambda_init)
        elif kind == 'CFGAT':
            self.conv1 = CFGATConv(input_dim, hidden_dim, heads=heads, dropout=drop_rate)
            self.conv2 = CFGATConv(hidden_dim * heads, output_dim, heads=1, dropout=drop_rate)
        elif kind == 'CFGAT_LPAT':
            self.conv1 = CFGATLPATConv(input_dim, hidden_dim, heads=heads, dropout=drop_rate, omega_init=omega_init, lambda_init=lambda_init)
            self.conv2 = CFGATLPATConv(hidden_dim * heads, output_dim, heads=1, dropout=drop_rate, omega_init=omega_init, lambda_init=lambda_init)
        elif kind == 'KAAGAT':
            self.conv1 = KAAGATConv(input_dim, hidden_dim, heads=heads, kan_layers=kan_layers, grid_size=grid_size,
                                    spline_order=spline_order, dropout=drop_rate)
            self.conv2 = KAAGATConv(hidden_dim * heads, output_dim, heads=1, kan_layers=kan_layers, grid_size=grid_size,
                                    spline_order=spline_order, dropout=drop_rate)
        elif kind == 'KAAGAT_LPAT':
            self.conv1 = KAAGATLPATConv(input_dim, hidden_dim, heads=heads, kan_layers=kan_layers, grid_size=grid_size,
                                    spline_order=spline_order, dropout=drop_rate, omega_init=omega_init, lambda_init=lambda_init)
            self.conv2 = KAAGATLPATConv(hidden_dim * heads, output_dim, heads=1, kan_layers=kan_layers, grid_size=grid_size,
                                    spline_order=spline_order, dropout=drop_rate, omega_init=omega_init, lambda_init=lambda_init)
        else:
            raise NotImplementedError

        self.reset_parameters()

    def forward(self, x, edge_index):
        x = F.dropout(x, p=args.drop_rate, training=self.training)
        x = self.conv1(x, edge_index)
        x = F.elu(x)
        x = F.dropout(x, p=args.drop_rate, training=self.training)
        x = self.conv2(x, edge_index)
        return x

    def reset_parameters(self):
        self.conv1.reset_parameters()
        self.conv2.reset_parameters()
# # Model
# class Model(torch.nn.Module):
#     def __init__(self, kind, input_dim, hidden_dim, output_dim, heads, drop_rate, 
#                  kan_layers, grid_size, spline_order, num_layers):
#         super(Model, self).__init__()
#         self.kind = kind
#         self.num_layers = num_layers
#         self.convs = nn.ModuleList()
        
#         if kind.endswith('LPAT'):
#             omega_init = 1.0
#             lambda_init = 5.0
            
#         # Create all layers
#         for i in range(num_layers):
#             in_channels = input_dim if i == 0 else hidden_dim * heads
#             out_channels = output_dim if i == num_layers - 1 else hidden_dim
#             layer_heads = 1 if i == num_layers - 1 else heads
            
#             if kind == 'GAT':
#                 conv = GATConv(in_channels, out_channels, heads=layer_heads, dropout=drop_rate)
#             elif kind == 'GAT_LPAT':
#                 conv = GATLPATConv(in_channels, out_channels, heads=layer_heads, dropout=drop_rate, 
#                                   omega_init=omega_init, lambda_init=lambda_init)
#             elif kind == 'GATv2':
#                 conv = GAT2Conv(in_channels, out_channels, heads=layer_heads, dropout=drop_rate)
#             elif kind == 'GATv2_LPAT':
#                 conv = GAT2LPATConv(in_channels, out_channels, heads=layer_heads, dropout=drop_rate, 
#                                    omega_init=omega_init, lambda_init=lambda_init)
#             elif kind == 'GLCN':
#                 conv = GLCNConv(in_channels, out_channels, heads=layer_heads, dropout=drop_rate)
#             elif kind == 'GLCN_LPAT':
#                 conv = GLCNLPATConv(in_channels, out_channels, heads=layer_heads, dropout=drop_rate, 
#                                    omega_init=omega_init, lambda_init=lambda_init)
#             elif kind == 'CFGAT':
#                 conv = CFGATConv(in_channels, out_channels, heads=layer_heads, dropout=drop_rate)
#             elif kind == 'CFGAT_LPAT':
#                 conv = CFGATLPATConv(in_channels, out_channels, heads=layer_heads, dropout=drop_rate, 
#                                     omega_init=omega_init, lambda_init=lambda_init)
#             elif kind == 'KAAGAT':
#                 conv = KAAGATConv(in_channels, out_channels, heads=layer_heads, kan_layers=kan_layers, 
#                                   grid_size=grid_size, spline_order=spline_order, dropout=drop_rate)
#             elif kind == 'KAAGAT_LPAT':
#                 conv = KAAGATLPATConv(in_channels, out_channels, heads=layer_heads, kan_layers=kan_layers, 
#                                      grid_size=grid_size, spline_order=spline_order, dropout=drop_rate, 
#                                      omega_init=omega_init, lambda_init=lambda_init)
#             else:
#                 raise NotImplementedError(f"Model kind {kind} not supported")
                
#             self.convs.append(conv)
            
#         self.reset_parameters()
        

#     def forward(self, x, edge_index):
#         for i, conv in enumerate(self.convs):
#             # Apply dropout and activation function except for the last layer
#             if i > 0:
#                 x = F.dropout(x, p=args.drop_rate, training=self.training)
                
#             x = conv(x, edge_index)
            
#             # Apply ELU activation function except for the last layer
#             if i < self.num_layers - 1:
#                 x = F.elu(x)
                
#         return x

#     def reset_parameters(self):
#         for conv in self.convs:
#             conv.reset_parameters()


# def get_flops(model, x, edge_index):
#     """More accurate FLOPs calculation method, considering specific implementations of different models"""
#     # Independent parameter count statistics
#     total_params = sum(p.numel() for p in model.parameters() if p.requires_grad)
    
#     # Initialize FLOPs counter
#     total_flops = 0
#     N, F_in = x.shape
#     E = edge_index.size(1)  # Number of edges
    
#     # Iterate through all layers
#     for i, conv in enumerate(model.convs):
#         # Calculate input and output dimensions for this layer
#         in_channels = dataset.num_features if i == 0 else args.hidden_dim * args.heads
#         out_channels = dataset.num_classes if i == args.num_layer - 1 else args.hidden_dim
#         heads = 1 if i == args.num_layer - 1 else args.heads
        
#         # Calculate FLOPs based on different model types
#         if isinstance(conv, (GATConv, GATLPATConv, GAT2Conv, GAT2LPATConv)):
#             # GAT series model computation
#             # Linear transformation
#             total_flops += N * in_channels * heads * out_channels * 2  # Multiply-add operations
#             # Attention calculation
#             total_flops += E * heads * out_channels * 4  # Attention calculation per edge
#             # Attention softmax
#             total_flops += E * heads * 5  # Softmax calculation per edge
            
#         elif isinstance(conv, (GLCNConv, GLCNLPATConv)):
#             # GLCN series model computation
#             # Linear transformation
#             total_flops += N * in_channels * heads * out_channels * 2
#             # Graph convolution calculation
#             total_flops += E * heads * out_channels * 2
#             # Additional similarity calculation
#             total_flops += E * in_channels * 4
            
#         elif isinstance(conv, (CFGATConv, CFGATLPATConv)):
#             # CFGAT series model computation
#             # Two linear transformations
#             total_flops += N * in_channels * heads * out_channels * 2 * 2
#             # Cosine similarity calculation
#             total_flops += E * heads * out_channels * 3
#             # Attention calculation
#             total_flops += E * heads * 5
            
#         elif isinstance(conv, (KAAGATConv, KAAGATLPATConv)):
#             # KAA-GAT series model computation
#             # Linear transformation
#             total_flops += N * in_channels * heads * out_channels * 2
#             # Additional computation for KAN layers (if used)
#             if args.kan_layers > 0:
#                 # KAN layer computation is approximately 2 times that of linear transformation
#                 total_flops += N * in_channels * heads * out_channels * 2 * 2
#             # Attention calculation
#             total_flops += E * heads * out_channels * 4
#             total_flops += E * heads * 5
            
#         # For LPAT models, add FLOPs for feature scaling transformation
#         if model.kind.endswith('LPAT') and i == 0:  # Only apply to first layer
#             # Feature scaling transformation computation:
#             # 1. Calculate feature mean: N * F_in
#             # 2. Calculate feature variance: N * F_in * 3 (subtract mean, square, calculate mean)
#             # 3. Calculate scaling factor: N * F_in * 3 (division, sigmoid)
#             # 4. Apply scaling: N * F_in (multiplication)
#             total_flops += N * F_in * 8
    
#     # Add FLOPs for activation functions
#     for i in range(args.num_layer - 1):
#         total_flops += N * args.hidden_dim * args.heads * 1  # ELU activation (approximately 1 FLOP/element)
    
#     # Add FLOPs for dropout
#     for i in range(1, args.num_layer):
#         total_flops += N * args.hidden_dim * args.heads * 1  # Dropout (approximately 1 FLOP/element)
    
#     return total_flops, total_params

# Update model instantiation
model = Model(
    kind=args.model, 
    input_dim=dataset.num_features, 
    hidden_dim=args.hidden_dim,
    output_dim=dataset.num_classes, 
    heads=args.heads, 
    drop_rate=args.drop_rate, 
    kan_layers=args.kan_layers,
    grid_size=args.grid_size, 
    spline_order=args.spline_order
    # num_layers=args.num_layer  # Add new parameter
).to(device)
optimizer = torch.optim.Adam(model.parameters(), lr=args.lr, weight_decay=0.0005)

# # Call after model initialization
# sample_x = data.x.to(device).float()
# sample_edge_index = data.edge_index.to(device)
# total_flops, total_params = get_flops(model, sample_x, sample_edge_index)
# # flops_m, params_m = clever_format([total_flops, total_params], "%.3f")


def train():
    model.train()
    optimizer.zero_grad()
    out = model(data.x, data.edge_index)
    loss = F.cross_entropy(out[data.train_mask], data.y[data.train_mask])
    loss.backward()
    print('the train loss is {}'.format(float(loss)))
    optimizer.step()


@torch.no_grad()
def test():
    model.eval()
    out = model(data.x, data.edge_index)
    _, pred = out.max(dim=1)
    train_correct = int(pred[data.train_mask].eq(data.y[data.train_mask]).sum().item())
    train_acc = train_correct / int(data.train_mask.sum())
    validate_correct = int(pred[data.val_mask].eq(data.y[data.val_mask]).sum().item())
    validate_acc = validate_correct / int(data.val_mask.sum())
    test_correct = int(pred[data.test_mask].eq(data.y[data.test_mask]).sum().item())
    test_acc = test_correct / int(data.test_mask.sum())
    return train_acc, validate_acc, test_acc

# Add necessary imports at the beginning of the file
import matplotlib
matplotlib.use('Agg')  # Use non-interactive backend, suitable for server environments
import matplotlib.pyplot as plt
from sklearn.manifold import TSNE
from sklearn.decomposition import PCA



# ====================== New visualization section ======================
@torch.no_grad()
def visualize(model, data, method='tsne'):
    model.eval()
    # Get model output
    out = model(data.x, data.edge_index)
    # Convert to numpy array
    embeddings = out.cpu().numpy()
    labels = data.y.cpu().numpy()
    
    print(f"Performing {method.upper()} dimensionality reduction...")
    
    if method == 'tsne':
        # Use t-SNE for dimensionality reduction
        reducer = TSNE(n_components=2, perplexity=30, 
                       learning_rate=200, random_state=42,
                       init='pca', n_iter=1000)
        embeddings_2d = reducer.fit_transform(embeddings)
    else:
        # Use PCA for dimensionality reduction
        reducer = PCA(n_components=2)
        embeddings_2d = reducer.fit_transform(embeddings)
    
    # Create visualization
    plt.figure(figsize=(12, 10))
    scatter = plt.scatter(
        embeddings_2d[:, 0], embeddings_2d[:, 1], 
        c=labels, cmap='tab10', s=10, alpha=0.7
    )
    
    # Add legend and title
    classes = [f'Class {i}' for i in range(dataset.num_classes)]
    plt.legend(handles=scatter.legend_elements()[0], 
               labels=classes, title="Classes")
    plt.title(f'{args.model} on {args.dataset} - {method.upper()} Visualization')
    plt.xlabel('Dimension 1')
    plt.ylabel('Dimension 2')
    plt.grid(alpha=0.3)
    
    # Save image
    filename = f'visualization_{args.model}_{args.dataset}_{method}.png'
    plt.savefig(filename, dpi=300, bbox_inches='tight')
    plt.close()
    print(f"Visualization saved to {filename}")
    
test_acc_list = []
best_acc = 0
time_list = []
total_params = sum(p.numel() for p in model.parameters() if p.requires_grad)
for round in range(args.train_round):
    # Reset random seed (ensure reproducibility)
    torch.manual_seed(args.seed + round)
    if torch.cuda.is_available():
        torch.cuda.manual_seed_all(args.seed + round)
    print('For the {} round'.format(round))
    start_time = time.time()
    best_val_acc = test_acc = 0
    model.reset_parameters()
    optimizer = torch.optim.Adam(model.parameters(), lr=args.lr, weight_decay=0.0005)
    print(f"Parameter details:")
    for name, param in model.named_parameters():
        print(f"{name}: {param.numel()} params")
    for epoch in range(args.epoch_num):
        print('---------------------------------------------------------------')
        print('For the {} epoch'.format(epoch))
        train()
        train_acc, val_acc, current_test_acc = test()
        print(
            'The train acc is {}, the val acc is {}, the test acc is {}.'.format(train_acc, val_acc, current_test_acc))
        if val_acc > best_val_acc:
            best_val_acc = val_acc
            test_acc = current_test_acc
    if best_acc < test_acc:
        best_acc = test_acc
        print("Generating visualization...")
        model.eval()

        # Generate both TSNE and PCA visualizations
        visualize(model, data, method='tsne')
        visualize(model, data, method='pca')
    test_acc_list.append(test_acc)
    end_time = time.time()
    time_list.append(end_time - start_time)
acc_avg = float(np.average(test_acc_list))
acc_std = float(np.std(test_acc_list))
time_avg = float(np.average(time_list))
print('Mission completes.')
print('The avg acc is {}, and the std is {}.'.format(acc_avg, acc_std))
print(test_acc_list)

# New result saving section
result_str = (f"Model: {args.model}, Dataset: {args.dataset}, "
             f"Avg Acc: {acc_avg:.4f}±{acc_std:.4f}, "
             f"Time: {time_avg:.2f},"
             # f"Flops: {total_flops/1e6:.2f}M,"
             f"Params:{total_params:.2f}\n")

# Write results to file
with open('results.txt', 'a') as f:  # Use append mode
    f.write(result_str)

print("Results have been saved to results.txt")