import os
import sys
import torch
import argparse
import numpy as np
import torch.nn.functional as F
from sklearn.metrics import roc_auc_score

from torch_geometric.utils import negative_sampling
from torch_geometric.datasets import Planetoid
import torch_geometric.transforms as T

from torch import nn

import time
from thop import profile
from torch_geometric.nn.conv import MessagePassing

# Get the four-level absolute path of current file (for modular calls)
current_dir = os.path.dirname(os.path.abspath(__file__))
project_root = os.path.dirname(os.path.dirname(os.path.dirname(current_dir)))
sys.path.insert(0, project_root)  # Insert at the beginning of path

# Import model modules
from model.GAT import GATConv
from model.GATv2 import GAT2Conv
from model.GLCN import GLCNConv
from model.CFGAT import CFGATConv
from model.KAA_GAT import KAAGATConv
from model.GAT_LPAT import GATLPATConv
from model.GATv2_LPAT import GAT2LPATConv
from model.GLCN_LPAT import GLCNLPATConv
from model.CFGAT_LPAT import CFGATLPATConv
from model.KAA_GAT_LPAT import KAAGATLPATConv

# Argument parser configuration
parser = argparse.ArgumentParser()
parser.add_argument('--hidden_dim', type=int, default=128, help='Hidden dimension size')
parser.add_argument('--model', type=str, default='KAAGAT', help='Model type to use')
parser.add_argument('--heads', type=int, default=1, help='Number of attention heads')
parser.add_argument('--device_num', type=int, default=0, help='GPU device number')
parser.add_argument('--epoch_num', type=int, default=300, help='Number of training epochs')
parser.add_argument('--lr', type=float, default=0.01, help='Learning rate')
parser.add_argument('--drop_rate', type=float, default=0, help='Dropout rate')
parser.add_argument('--seed', type=int, default=1, help='Random seed')
parser.add_argument('--dataset', type=str, default='Cora', help='Dataset to test')
parser.add_argument('--train_round', type=int, default=10, help='Number of training rounds')

# KAN specific parameters
parser.add_argument('--kan_layers', type=int, default=0, help='Number of KAN layers')
parser.add_argument('--grid_size', type=int, default=1, help='Grid size for KAN')
parser.add_argument('--spline_order', type=int, default=1, help='Spline order for KAN')

args = parser.parse_args()

# Set random seed for reproducibility
random_seed = args.seed
torch.manual_seed(random_seed)
torch.cuda.manual_seed(random_seed)
torch.backends.cudnn.benchmark = False
torch.backends.cudnn.deterministic = True

# Device configuration
device = torch.device(f'cuda:{args.device_num}' if torch.cuda.is_available() else 'cpu')

# Load dataset
transform = T.Compose([
    T.NormalizeFeatures(),
    T.ToDevice(device),
    T.RandomLinkSplit(num_val=0.05, num_test=0.1, is_undirected=True,
                      add_negative_train_samples=False),
])
dataset = Planetoid(root="./dataset/", name=args.dataset, transform=transform)
train_data, val_data, test_data = dataset[0]


class Model(torch.nn.Module):
    """Graph Neural Network Model for Link Prediction"""
    
    def __init__(self, kind, input_dim, hidden_dim, output_dim, heads, drop_rate, kan_layers, grid_size, spline_order):
        super(Model, self).__init__()
        self.kind = kind  # Save model type
        
        if kind.endswith('LPAT'):
            # Define initial values for LPAT parameters
            omega_init = 1.0
            lambda_init = 5.0
            
        # Initialize convolution layers based on model type
        if kind == 'GAT':
            self.conv1 = GATConv(input_dim, hidden_dim, heads=heads, dropout=drop_rate)
            self.conv2 = GATConv(hidden_dim * heads, output_dim, heads=1, dropout=drop_rate)
        elif kind == 'GAT_LPAT':
            self.conv1 = GATLPATConv(input_dim, hidden_dim, heads=heads, dropout=drop_rate, omega_init=0.0, lambda_init=0.0)
            self.conv2 = GATLPATConv(hidden_dim * heads, output_dim, heads=1, dropout=drop_rate, omega_init=omega_init, lambda_init=lambda_init)
        elif kind == 'GATv2':
            self.conv1 = GAT2Conv(input_dim, hidden_dim, heads=heads, dropout=drop_rate)
            self.conv2 = GAT2Conv(hidden_dim * heads, output_dim, heads=1, dropout=drop_rate)
        elif kind == 'GATv2_LPAT':
            self.conv1 = GAT2LPATConv(input_dim, hidden_dim, heads=heads, dropout=drop_rate, omega_init=0.0, lambda_init=0.0)
            self.conv2 = GAT2LPATConv(hidden_dim * heads, output_dim, heads=1, dropout=drop_rate, omega_init=omega_init, lambda_init=lambda_init)
        elif kind == 'GLCN':
            self.conv1 = GLCNConv(input_dim, hidden_dim, heads=heads, dropout=drop_rate)
            self.conv2 = GLCNConv(hidden_dim * heads, output_dim, heads=1, dropout=drop_rate)
        elif kind == 'GLCN_LPAT':
            self.conv1 = GLCNLPATConv(input_dim, hidden_dim, heads=heads, dropout=drop_rate, omega_init=0.0, lambda_init=0.0)
            self.conv2 = GLCNLPATConv(hidden_dim * heads, output_dim, heads=1, dropout=drop_rate, omega_init=omega_init, lambda_init=lambda_init)
        elif kind == 'CFGAT':
            self.conv1 = CFGATConv(input_dim, hidden_dim, heads=heads, dropout=drop_rate)
            self.conv2 = CFGATConv(hidden_dim * heads, output_dim, heads=1, dropout=drop_rate)
        elif kind == 'CFGAT_LPAT':
            self.conv1 = CFGATLPATConv(input_dim, hidden_dim, heads=heads, dropout=drop_rate, omega_init=0.0, lambda_init=0.0)
            self.conv2 = CFGATLPATConv(hidden_dim * heads, output_dim, heads=1, dropout=drop_rate, omega_init=omega_init, lambda_init=lambda_init)
        elif kind == 'KAAGAT':
            self.conv1 = KAAGATConv(input_dim, hidden_dim, heads=heads, kan_layers=kan_layers, grid_size=grid_size,
                                    spline_order=spline_order, dropout=drop_rate)
            self.conv2 = KAAGATConv(hidden_dim * heads, output_dim, heads=1, kan_layers=kan_layers, grid_size=grid_size,
                                    spline_order=spline_order, dropout=drop_rate)
        elif kind == 'KAAGAT_LPAT':
            self.conv1 = KAAGATLPATConv(input_dim, hidden_dim, heads=heads, kan_layers=kan_layers, grid_size=grid_size,
                                    spline_order=spline_order, dropout=drop_rate, omega_init=0.0, lambda_init=0.0)
            self.conv2 = KAAGATLPATConv(hidden_dim * heads, output_dim, heads=1, kan_layers=kan_layers, grid_size=grid_size,
                                    spline_order=spline_order, dropout=drop_rate, omega_init=omega_init, lambda_init=lambda_init)
        else:
            raise NotImplementedError(f"Model type {kind} not implemented")

        self.drop_rate = drop_rate
        self.reset_parameters()
        
    def encode(self, x, edge_index):
        """Encode node features into embeddings"""
        x = F.dropout(x, p=self.drop_rate, training=self.training)
        x = self.conv1(x, edge_index)
        x = x.relu()
        x = F.dropout(x, p=self.drop_rate, training=self.training)
        return self.conv2(x, edge_index)
    
    def forward(self, x, edge_index):
        """Forward pass through the model"""
        return self.encode(x, edge_index)

    def decode(self, z, edge_label_index):
        """Decode edge probabilities from node embeddings"""
        return (z[edge_label_index[0]] * z[edge_label_index[1]]).sum(dim=-1)

    def decode_all(self, z):
        """Decode all possible edges from node embeddings"""
        prob_adj = z @ z.t()
        return (prob_adj > 0).nonzero(as_tuple=False).t()

    def reset_parameters(self):
        """Reset model parameters"""
        self.conv1.reset_parameters()
        self.conv2.reset_parameters()


def get_link_labels(pos_edge_index, neg_edge_index):
    """Create link labels for positive and negative edges"""
    num_links = pos_edge_index.size(1) + neg_edge_index.size(1)
    link_labels = torch.zeros(num_links, dtype=torch.float, device=device)
    link_labels[:pos_edge_index.size(1)] = 1.
    return link_labels


def train():
    """Training function for one epoch"""
    model.train()
    optimizer.zero_grad()
    z = model.encode(train_data.x, train_data.edge_index)

    # We perform a new round of negative sampling for every training epoch:
    neg_edge_index = negative_sampling(
        edge_index=train_data.edge_index, num_nodes=train_data.num_nodes,
        num_neg_samples=train_data.edge_label_index.size(1), method='sparse')

    edge_label_index = torch.cat(
        [train_data.edge_label_index, neg_edge_index],
        dim=-1,
    )
    edge_label = torch.cat([
        train_data.edge_label,
        train_data.edge_label.new_zeros(neg_edge_index.size(1))
    ], dim=0)

    out = model.decode(z, edge_label_index).view(-1)
    loss = criterion(out, edge_label)
    loss.backward()
    optimizer.step()
    return loss


@torch.no_grad()
def test(data):
    """Testing function"""
    model.eval()
    z = model.encode(data.x, data.edge_index)
    out = model.decode(z, data.edge_label_index).view(-1).sigmoid()
    return roc_auc_score(data.edge_label.cpu().numpy(), out.cpu().numpy())


def get_flops_and_params(model, x, edge_index):
    """Manually calculate model FLOPs and parameter count"""
    N = x.size(0)  # Number of nodes
    E = edge_index.size(1)  # Number of edges
    F_in = x.size(1)  # Input feature dimension
    
    total_flops = 0
    total_params = 0
    
    # Calculate parameter count
    for name, param in model.named_parameters():
        if param.requires_grad:
            total_params += param.numel()
    
    # First convolution layer
    # Input dimension: F_in, Output dimension: args.hidden_dim * args.heads
    # Linear transformation FLOPs (2 * F_in * (args.hidden_dim * args.heads) * N)
    total_flops += 2 * N * F_in * (args.hidden_dim * args.heads)
    
    # Attention calculation (approximately 4 operations per edge * E * args.heads)
    total_flops += 4 * E * args.heads
    
    # Activation function (1 operation per node * N * (args.hidden_dim * args.heads))
    total_flops += N * (args.hidden_dim * args.heads)
    
    # Dropout (1 operation per node * N * (args.hidden_dim * args.heads))
    total_flops += N * (args.hidden_dim * args.heads)
    
    # Second convolution layer
    # Input dimension: args.hidden_dim * args.heads, Output dimension: 64
    # Linear transformation FLOPs (2 * N * (args.hidden_dim * args.heads) * 64)
    total_flops += 2 * N * (args.hidden_dim * args.heads) * 64
    
    # Attention calculation (approximately 4 operations per edge * E)
    total_flops += 4 * E
    
    # For LPAT models, add FLOPs for LPAT mechanism
    if model.kind.endswith('LPAT'):
        # LPAT mechanism computational cost:
        # 1. Calculate feature mean: N * F_in
        # 2. Calculate feature variance: 3 * N * F_in (subtraction, square, summation)
        # 3. Calculate scaling factor: 3 * N * F_in (division, multiplication, addition)
        # 4. Apply scaling: N * F_in (multiplication)
        total_flops += (N * F_in) + (3 * N * F_in) + (3 * N * F_in) + (N * F_in)
    
    # Additional computations for specific model types
    if 'GLCN' in model.kind or 'CFGAT' in model.kind:
        # Additional FLOPs for similarity calculation (approximately 3 operations per edge * E)
        total_flops += 3 * E
    
    if 'KAA' in model.kind and args.kan_layers > 0:
        # Additional computational cost for KAN layers (approximately 2 * F_in * (args.hidden_dim * args.heads) per node)
        total_flops += 2 * N * F_in * (args.hidden_dim * args.heads)
    
    return total_flops, total_params


# Create model (no longer needs external parameters)
model = Model(
    kind=args.model, 
    input_dim=dataset.num_features, 
    hidden_dim=args.hidden_dim, 
    output_dim=64,
    heads=args.heads, 
    drop_rate=args.drop_rate, 
    kan_layers=args.kan_layers, 
    grid_size=args.grid_size, 
    spline_order=args.spline_order
).to(device)

optimizer = torch.optim.Adam(model.parameters(), lr=args.lr)
criterion = torch.nn.BCEWithLogitsLoss()

# Get model sample for FLOPs calculation
sample_x = train_data.x.float()
sample_edge_index = train_data.edge_index
flops_total, params_total = get_flops_and_params(model, train_data.x, train_data.edge_index)

# Training loop
test_auc_list = []
time_list = []

for round in range(args.train_round):
    # Reset random seed (ensure reproducibility)
    torch.manual_seed(args.seed + round)
    if torch.cuda.is_available():
        torch.cuda.manual_seed_all(args.seed + round)
    
    print(f'\n=== Round {round+1}/{args.train_round} ===')
    start_time = time.time()
    best_val_auc = test_auc = 0
    model.reset_parameters()
    # Create new optimizer (ensure optimizer state reset)
    optimizer = torch.optim.Adam(model.parameters(), lr=args.lr)
    
    print(f"Parameter details:")
    for name, param in model.named_parameters():
        print(f"{name}: {param.numel()} params")
    
    for epoch in range(1, args.epoch_num + 1):
        loss = train()
        val_auc = test(val_data)
        tmp_test_auc = test(test_data)
        
        print('-' * 80)
        print(f'Epoch {epoch:03d}: Loss={loss:.4f}, Val AUC={val_auc:.4f}, Test AUC={tmp_test_auc:.4f}')
        
        if val_auc > best_val_auc:
            best_val_auc = val_auc
            test_auc = tmp_test_auc
    
    test_auc_list.append(test_auc)
    end_time = time.time()
    run_time = end_time - start_time
    time_list.append(run_time)
    
    print(f'Round {round+1} completed. Test AUC: {test_auc:.4f}, Time: {run_time:.2f}s')

# Calculate average results
auc_avg = float(np.mean(test_auc_list))
auc_std = float(np.std(test_auc_list))
time_avg = float(np.mean(time_list))

print('\n' + '=' * 80)
print('Mission completes.')
print(f'Dataset: {args.dataset}, Model: {args.model}')
print(f'Average AUC: {auc_avg:.4f} ± {auc_std:.4f}')
print(f'Average Time: {time_avg:.2f}s')
print(f'Model FLOPs: {flops_total/1e6:.2f}M')
print(f'Model Parameters: {params_total}')

# Save results to file
result_str = (f"Dataset: {args.dataset}, Model: {args.model}, Average AUC: {auc_avg:.4f}±{auc_std:.4f}, "
              f"Average Time: {time_avg:.2f}, FLOPs: {flops_total/1e6:.2f}, Params: {params_total}\n")

with open('link_results.txt', 'a') as f:
    f.write(result_str)

print("Results have been saved to link_results.txt")