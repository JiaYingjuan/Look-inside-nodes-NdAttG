#!/bin/bash

BASE_DIR=$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)
cd $BASE_DIR

export PYTHONPATH="$BASE_DIR:$PYTHONPATH"


### QM9

#### GAT

python -m graph_regression.train_qm9 \
  --model GAT
  
#### GAT+LPAT

python -m graph_regression.train_qm9 \
  --model GAT_LPAT


#### KAAGAT

python -m graph_regression.train_qm9 \
  --model KAAGAT
  
#### KAAGAT+LPAT

python -m graph_regression.train_qm9 \
  --model KAAGAT_LPAT

#### GLCN

python -m graph_regression.train_qm9 \
  --model GLCN
  
#### GLCN+LPAT

python -m graph_regression.train_qm9 \
  --model GLCN_LPAT

#### CFGAT

python -m graph_regression.train_qm9 \
  --model CFGAT
  
#### CFGAT+LPAT

python -m graph_regression.train_qm9 \
  --model CFGAT_LPAT

