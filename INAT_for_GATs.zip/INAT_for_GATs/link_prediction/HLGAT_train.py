import os
import sys
import torch
import argparse
import numpy as np
import torch.nn.functional as F
from sklearn.metrics import roc_auc_score

from torch_geometric.utils import negative_sampling
from torch_geometric.datasets import Planetoid
import torch_geometric.transforms as T
from torch_geometric.utils import degree

from torch import nn
import time
from thop import profile
from torch_geometric.nn.conv import MessagePassing

# Get the four-level absolute path of current file (for modular calls)
current_dir = os.path.dirname(os.path.abspath(__file__))
project_root = os.path.dirname(os.path.dirname(os.path.dirname(current_dir)))
sys.path.insert(0, project_root)  # Insert at the beginning of path

# Import HLGAT models
from model.HLGAT import HLGAT
from model.HLGAT_LPAT import HLGAT_LPAT

# Argument parser configuration
parser = argparse.ArgumentParser(description='HLGAT Link Prediction Training')

# HLGAT specific parameters
parser.add_argument('--model', type=str, default='HLGAT_LPAT', help='Model type to use')
parser.add_argument('--hidden_dim', type=int, default=128, help='Hidden dimension size')
parser.add_argument('--num_layers', type=int, default=1, help='Number of HLGAT layers')
parser.add_argument('--p_l', type=float, default=0.1, help='Leak coefficient for low-pass filter')
parser.add_argument('--p_h', type=float, default=0.4, help='Leak coefficient for high-pass filter')
parser.add_argument('--eps', type=float, default=0.9, help='Residual connection weight')

# General training parameters
parser.add_argument('--device_num', type=int, default=0, help='GPU device number')
parser.add_argument('--epoch_num', type=int, default=300, help='Number of training epochs')
parser.add_argument('--lr', type=float, default=0.001, help='Learning rate')
parser.add_argument('--drop_rate', type=float, default=0.3, help='Dropout rate')
parser.add_argument('--seed', type=int, default=1, help='Random seed')
parser.add_argument('--dataset', type=str, default='Cora', help='Dataset to test')
parser.add_argument('--train_round', type=int, default=10, help='Number of training rounds')

args = parser.parse_args()

# Set random seed for reproducibility
random_seed = args.seed
torch.manual_seed(random_seed)
if torch.cuda.is_available():
    torch.cuda.manual_seed(random_seed)
    torch.cuda.manual_seed_all(random_seed)
torch.backends.cudnn.benchmark = False
torch.backends.cudnn.deterministic = True

# Device selection
device = torch.device(f'cuda:{args.device_num}' if torch.cuda.is_available() else 'cpu')
print(f"Using device: {device}")

# Data loading and preprocessing
transform = T.Compose([
    T.NormalizeFeatures(),
    T.ToDevice(device),
    T.RandomLinkSplit(num_val=0.05, num_test=0.1, is_undirected=True,
                      add_negative_train_samples=False),
])
dataset = Planetoid(root="./dataset/", name=args.dataset, transform=transform)
train_data, val_data, test_data = dataset[0]

# Calculate degree normalization factor (specific to HLGAT)
# Calculate degree for each node
row = train_data.edge_index[0]
deg = degree(row, train_data.num_nodes, dtype=torch.float).to(device)  # Degree vector for each node
deg_inv_sqrt = deg.pow(-0.5)  # Degree normalization factor
deg_inv_sqrt[deg_inv_sqrt == float('inf')] = 0  # Handle nodes with degree 0
norm = deg_inv_sqrt  # Use degree normalization factor

# Model definition based on selected type
if args.model == 'HLGAT':
    class HLGATLinkModel(nn.Module):
        """HLGAT Model for Link Prediction Task"""
        
        def __init__(self, in_channels, hidden_dim, num_layers, dropout, p_l, p_h, eps):
            super(HLGATLinkModel, self).__init__()
            # HLGAT encoder
            self.encoder = HLGAT(
                in_channels=in_channels,
                hidden_dim=hidden_dim,
                out_channels=hidden_dim,  # Output dimension same as hidden dimension
                num_layers=num_layers,
                dropout=dropout,
                p_l=p_l,
                p_h=p_h,
                eps=eps
            )
            self.dropout = dropout
            self.num_layers = num_layers

        def forward(self, x, edge_index, norm):
            """Forward pass through the model"""
            return self.encoder(x, edge_index, norm)

        def encode(self, x, edge_index, norm):
            """Generate node embeddings"""
            return self.encoder(x, edge_index, norm)

        def decode(self, z, edge_label_index):
            """Inner product decoder: compute inner product of node pairs as link scores"""
            return (z[edge_label_index[0]] * z[edge_label_index[1]]).sum(dim=-1)

        def decode_all(self, z):
            """Full graph decoding: compute all possible links"""
            prob_adj = z @ z.t()
            return (prob_adj > 0).nonzero(as_tuple=False).t()

        def reset_parameters(self):
            """Reset model parameters"""
            self.encoder.reset_parameters()
    
    # Initialize model
    model = HLGATLinkModel(
        in_channels=dataset.num_features,
        hidden_dim=args.hidden_dim,
        num_layers=args.num_layers,
        dropout=args.drop_rate,
        p_l=args.p_l,
        p_h=args.p_h,
        eps=args.eps
    ).to(device)

elif args.model == 'HLGAT_LPAT':
    class HLGAT_LPAT_LinkModel(nn.Module):
        """HLGAT LPAT Model for Link Prediction Task"""
        
        def __init__(self, in_channels, hidden_dim, num_layers, dropout, p_l, p_h, eps, omega_init, lambda_init):
            super(HLGAT_LPAT_LinkModel, self).__init__()
            # HLGAT_LPAT encoder
            self.encoder = HLGAT_LPAT(
                in_channels=in_channels,
                hidden_dim=hidden_dim,
                out_channels=hidden_dim,  # Output dimension same as hidden dimension
                num_layers=num_layers,
                dropout=dropout,
                p_l=p_l,
                p_h=p_h,
                eps=eps,
                omega_init=omega_init,
                lambda_init=lambda_init
            )
            self.dropout = dropout
            self.num_layers = num_layers

        def forward(self, x, edge_index, norm):
            """Forward pass through the model"""
            return self.encoder(x, edge_index, norm)

        def encode(self, x, edge_index, norm):
            """Generate node embeddings"""
            return self.encoder(x, edge_index, norm)

        def decode(self, z, edge_label_index):
            """Inner product decoder: compute inner product of node pairs as link scores"""
            return (z[edge_label_index[0]] * z[edge_label_index[1]]).sum(dim=-1)

        def decode_all(self, z):
            """Full graph decoding: compute all possible links"""
            prob_adj = z @ z.t()
            return (prob_adj > 0).nonzero(as_tuple=False).t()

        def reset_parameters(self):
            """Reset model parameters"""
            self.encoder.reset_parameters()
    
    model = HLGAT_LPAT_LinkModel(
        in_channels=dataset.num_features,
        hidden_dim=args.hidden_dim,
        num_layers=args.num_layers,
        dropout=args.drop_rate,
        p_l=args.p_l,
        p_h=args.p_h,
        eps=args.eps,
        omega_init=1.0,
        lambda_init=5.0
    ).to(device)

# Create optimizer
optimizer = torch.optim.Adam(model.parameters(), lr=args.lr, weight_decay=5e-4)
criterion = torch.nn.BCEWithLogitsLoss()


def get_link_labels(pos_edge_index, neg_edge_index):
    """Create link labels for positive and negative edges"""
    num_links = pos_edge_index.size(1) + neg_edge_index.size(1)
    link_labels = torch.zeros(num_links, dtype=torch.float, device=device)
    link_labels[:pos_edge_index.size(1)] = 1.
    return link_labels


def train():
    """Training function for one epoch"""
    model.train()
    optimizer.zero_grad()
    
    # Generate node embeddings
    z = model.encode(train_data.x, train_data.edge_index, norm)
    
    # Negative sampling
    neg_edge_index = negative_sampling(
        edge_index=train_data.edge_index, 
        num_nodes=train_data.num_nodes,
        num_neg_samples=train_data.edge_label_index.size(1), 
        method='sparse'
    )
    
    # Combine positive and negative samples
    edge_label_index = torch.cat(
        [train_data.edge_label_index, neg_edge_index],
        dim=-1,
    )
    
    # Create labels
    edge_label = get_link_labels(train_data.edge_label_index, neg_edge_index)
    
    # Predict links
    out = model.decode(z, edge_label_index).view(-1)
    
    # Calculate loss
    loss = criterion(out, edge_label)
    loss.backward()
    optimizer.step()
    return loss.item()


@torch.no_grad()
def test(data):
    """Testing function"""
    model.eval()
    z = model.encode(data.x, data.edge_index, norm)
    out = model.decode(z, data.edge_label_index).view(-1).sigmoid()
    return roc_auc_score(data.edge_label.cpu().numpy(), out.cpu().numpy())


def get_flops_and_params(model, x, edge_index, norm):
    """Accurately calculate model FLOPs and parameter count"""
    N = x.size(0)  # Number of nodes
    E = edge_index.size(1)  # Number of edges
    F_in = x.size(1)  # Input feature dimension
    
    total_flops = 0
    total_params = 0
    
    # Calculate parameter count
    for name, param in model.named_parameters():
        if param.requires_grad:
            total_params += param.numel()
    
    # Calculate FLOPs layer by layer
    for i in range(1):
        # Determine current layer input/output dimensions
        if i == 0:
            in_dim = F_in
        else:
            in_dim = args.hidden_dim
            
        out_dim = args.hidden_dim  # All hidden layers have same output dimension
        
        # Linear transformation FLOPs (2 * in_dim * out_dim * N)
        # Two branches (low-pass and high-pass) each have one linear transformation
        total_flops += 2 * 2 * N * in_dim * out_dim
        
        # Graph convolution operation FLOPs (4 operations per edge * E)
        # Two branches (low-pass and high-pass) each have one graph convolution
        total_flops += 2 * 4 * E
        
        # Filter operation FLOPs (2 operations per node * N)
        total_flops += 2 * N
        
        # Gating mechanism FLOPs (2 * (2 * out_dim) * out_dim * N)
        # Input: 2 * out_dim (concatenation of two branch outputs)
        # Output: out_dim
        total_flops += 2 * N * (2 * out_dim) * out_dim
        
        # Residual connection FLOPs (1 operation per node * N * out_dim)
        total_flops += N * out_dim
        
        # Activation function FLOPs (ReLU, 1 operation per node * N * out_dim)
        total_flops += N * out_dim
    
    # For LPAT models, add FLOPs for LPAT mechanism
    if args.model == 'HLGAT_LPAT':
        # Add LPAT computation per layer
        for i in range(1):
            # Current layer input dimension
            if i == 0:
                in_dim = F_in
            else:
                in_dim = args.hidden_dim
            
            # LPAT mechanism computational cost:
            # 1. Calculate feature mean: N * in_dim
            # 2. Calculate feature variance: 3 * N * in_dim (subtraction, square, summation)
            # 3. Calculate scaling factor: 3 * N * in_dim (division, multiplication, addition)
            # 4. Apply scaling: N * in_dim (multiplication)
            total_flops += (N * in_dim) + (3 * N * in_dim) + (3 * N * in_dim) + (N * in_dim)
    
    return total_flops, total_params


# Calculate model FLOPs and parameters
total_flops, params_m = get_flops_and_params(model, train_data.x, train_data.edge_index, norm)

# Training loop
test_auc_list = []
time_list = []

for round_idx in range(args.train_round):
    # Reset random seed
    torch.manual_seed(args.seed + round_idx)
    if torch.cuda.is_available():
        torch.cuda.manual_seed_all(args.seed + round_idx)
    
    print(f'\n===== Training Round {round_idx+1}/{args.train_round} =====')
    
    start_time = time.time()
    best_val_auc = 0.0
    best_test_auc = 0.0
    model.reset_parameters()
    optimizer = torch.optim.Adam(model.parameters(), lr=args.lr, weight_decay=5e-4)
    
    for epoch in range(1, args.epoch_num + 1):
        loss = train()
        val_auc = test(val_data)
        test_auc = test(test_data)
        
        # Update best test accuracy
        if val_auc > best_val_auc:
            best_val_auc = val_auc
            best_test_auc = test_auc
        
        # Print progress every 10 epochs
        if epoch % 10 == 0 or epoch == 1:
            print(f'Epoch: {epoch:03d}, Loss: {loss:.4f}, '
                  f'Val AUC: {val_auc:.4f}, Test AUC: {test_auc:.4f}')
    
    end_time = time.time()
    round_time = end_time - start_time
    time_list.append(round_time)
    test_auc_list.append(best_test_auc)
    
    print(f'Round {round_idx+1} completed. Best Test AUC: {best_test_auc:.4f}, Time: {round_time:.2f}s')

# Calculate average accuracy and standard deviation
auc_avg = np.mean(test_auc_list)
auc_std = np.std(test_auc_list)
time_avg = np.mean(time_list)

print('\n===== Final Results =====')
print(f'Average Test AUC: {auc_avg:.4f} ± {auc_std:.4f}')
print(f'Average Training Time per Round: {time_avg:.2f}s')

# Save results
result_str = (f"Model: {args.model}, Dataset: {args.dataset}, "
             f"Avg AUC: {auc_avg:.4f}±{auc_std:.4f}, "
             f"Time: {time_avg:.2f}s, "
             f"Params: {params_m}, FLOPs: {total_flops/1e6:.2f}M\n")

# Write results to file
with open('link_results.txt', 'a') as f:  # Use append mode
    f.write(result_str)

print("Results have been saved to link_results.txt")