import os
import sys
import torch
import argparse
import numpy as np
import dgl
from sklearn.metrics import roc_auc_score

from torch_geometric.utils import negative_sampling
from torch_geometric.datasets import Planetoid
import torch_geometric.transforms as T

from thop import profile
THOP_AVAILABLE = True

sys.path.append(os.path.join(os.path.dirname(__file__), '..'))

from model.GT.graph_transformer_net import GraphTransformerNet
from model.GT.graph_transformer_net_LPAT import GraphTransformerNet_LPAT
from model.GT.laplace_pos_enc import laplacian_positional_encoding

torch.autograd.set_detect_anomaly(True)

# Argument parser configuration
parser = argparse.ArgumentParser()
parser.add_argument('--hidden_dim', type=int, default=128, help='Hidden dimension size')
parser.add_argument('--model', type=str, default='GT', help='Model type to use')
parser.add_argument('--heads', type=int, default=1, help='Number of attention heads')
parser.add_argument('--device_num', type=int, default=0, help='GPU device number')
parser.add_argument('--epoch_num', type=int, default=1000, help='Number of training epochs')
parser.add_argument('--lr', type=float, default=0.0001, help='Learning rate')
parser.add_argument('--seed', type=int, default=1, help='Random seed')
parser.add_argument('--dataset', type=str, default='Cora', help='Dataset to test')
parser.add_argument('--train_round', type=int, default=5, help='Number of training rounds')
parser.add_argument('--pos_enc_dim', type=int, default=8, help='Laplacian positional encoding dimension')
parser.add_argument('--layers', type=int, default=1, help='Number of layers')
parser.add_argument('--in_feat_dropout', type=float, default=0, help='Input feature dropout rate')
parser.add_argument('--dropout', type=float, default=0, help='Dropout rate')

args = parser.parse_args()

# Device configuration
device = torch.device(f'cuda:{args.device_num}' if torch.cuda.is_available() else 'cpu')

# Set random seed for reproducibility
random_seed = args.seed
torch.manual_seed(random_seed)
torch.cuda.manual_seed(random_seed)
torch.backends.cudnn.benchmark = False
torch.backends.cudnn.deterministic = True


def pyg_to_dgl(data):
    """Converts a PyTorch Geometric (PyG) data object to a Deep Graph Library (DGL) graph object."""
    edge_index = data.edge_index
    src = edge_index[0].to('cpu')
    dst = edge_index[1].to('cpu')
    
    g = dgl.graph((src, dst))
    g.ndata['feat'] = data.x[:g.num_nodes(), :].to('cpu')
    
    num_existing_nodes = g.num_nodes()
    num_total_nodes = data.x.size(0)
    
    if num_total_nodes > num_existing_nodes:
        num_new_nodes = num_total_nodes - num_existing_nodes
        g.add_nodes(num_new_nodes)
        g.ndata['feat'][num_existing_nodes:] = data.x[num_existing_nodes:, :].to('cpu')
    return g


# Load dataset
transform = T.Compose([
    T.NormalizeFeatures(),
    T.ToDevice(device),
    T.RandomLinkSplit(num_val=0.05, num_test=0.1, is_undirected=True,
                      add_negative_train_samples=False),
])
dataset = Planetoid(root="./dataset/", name=args.dataset, transform=transform)
train_data, val_data, test_data = dataset[0]

# Convert PyG graphs to DGL and apply positional encoding
train_graph = pyg_to_dgl(train_data)
train_graph = laplacian_positional_encoding(train_graph, args.pos_enc_dim)
train_graph = train_graph.to(device)

val_graph = pyg_to_dgl(val_data)
val_graph = laplacian_positional_encoding(val_graph, args.pos_enc_dim)
val_graph = val_graph.to(device)

test_graph = pyg_to_dgl(test_data)
test_graph = laplacian_positional_encoding(test_graph, args.pos_enc_dim)
test_graph = test_graph.to(device)

# Network parameters configuration
net_params = {
    'kind': args.model,
    'in_dim': dataset.num_features,
    'hidden_dim': args.hidden_dim,
    'out_dim': args.hidden_dim,
    'n_classes': dataset.num_classes,
    'n_heads': args.heads,
    'in_feat_dropout': args.in_feat_dropout,
    'dropout': args.dropout,
    'pos_enc_dim': args.pos_enc_dim,
    'L': args.layers,
    'layer_norm': False,
    'batch_norm': True,
    'residual': True,
    'device': device,
    'lap_pos_enc': True,
    'wl_pos_enc': False,
    'omega_init': 0.0,
    'lambda_init': 0.0,
}


def decode(z, edge_label_index):
    """Decode edge probabilities from node embeddings"""
    return (z[edge_label_index[0]] * z[edge_label_index[1]]).sum(dim=-1)


def train():
    """Training function for one epoch"""
    model.train()
    optimizer.zero_grad()
    z = model(train_graph, train_graph.ndata['feat'], None, train_graph.ndata['lap_pos_enc'])

    # We perform a new round of negative sampling for every training epoch:
    neg_edge_index = negative_sampling(
        edge_index=train_data.edge_index, num_nodes=train_data.num_nodes,
        num_neg_samples=train_data.edge_label_index.size(1), method='sparse')

    edge_label_index = torch.cat(
        [train_data.edge_label_index, neg_edge_index],
        dim=-1,
    )
    edge_label = torch.cat([
        train_data.edge_label,
        train_data.edge_label.new_zeros(neg_edge_index.size(1))
    ], dim=0)

    out = decode(z, edge_label_index).view(-1)
    loss = criterion(out, edge_label)
    loss.backward()  # Perform the backward pass
    optimizer.step()
    return loss


@torch.no_grad()
def test():
    """Testing function"""
    model.eval()
    z_train = model(train_graph, train_graph.ndata['feat'], None, train_graph.ndata['lap_pos_enc'])
    z_test = model(test_graph, test_graph.ndata['feat'], None, test_graph.ndata['lap_pos_enc'])
    z_val = model(val_graph, val_graph.ndata['feat'], None, val_graph.ndata['lap_pos_enc'])
    out_test = decode(z_test, test_data.edge_label_index).view(-1).sigmoid()
    out_val = decode(z_val, val_data.edge_label_index).view(-1).sigmoid()

    return roc_auc_score(val_data.edge_label.cpu().numpy(), out_val.cpu().numpy()), roc_auc_score(test_data.edge_label.cpu().numpy(), out_test.cpu().numpy())


def compute_flops_params(model, graph, feat, pos_enc):
    """Calculate model FLOPs and parameter count"""
    model.eval()  # Set to evaluation mode
    if THOP_AVAILABLE:
        # Use model object directly instead of wrapper function
        flops, params = profile(model, inputs=(graph, feat, None, pos_enc), verbose=False)
        return flops, params
    else:
        total_params = sum(p.numel() for p in model.parameters() if p.requires_grad)
        return 0, total_params


# Training loop
test_auc_list = []
for round in range(args.train_round):
    # Move net_params definition inside the loop
    net_params = {
        'kind': args.model,
        'in_dim': dataset.num_features,
        'hidden_dim': args.hidden_dim,
        'out_dim': args.hidden_dim,
        'n_classes': dataset.num_classes,
        'n_heads': args.heads,
        'in_feat_dropout': args.in_feat_dropout,
        'dropout': args.dropout,
        'pos_enc_dim': args.pos_enc_dim,
        'L': args.layers,
        'layer_norm': False,
        'batch_norm': True,
        'residual': True,
        'device': device,
        'lap_pos_enc': True,
        'wl_pos_enc': False,
        'omega_init': 1.0,
        'lambda_init': 5.0,
    }
    
    # Reset random seed for reproducibility
    torch.manual_seed(args.seed + round)  # Add round offset to ensure different initializations
    torch.cuda.manual_seed(args.seed + round)
    
    print(f'For the {round} round')
    best_val_auc = test_auc = 0
    
    # Initialize model based on type
    if args.model == "GT":
        model = GraphTransformerNet(net_params).to(net_params['device'])
    elif args.model == "GT_LPAT":
        model = GraphTransformerNet_LPAT(net_params).to(net_params['device'])
        
    # Calculate FLOPs and parameters only in the first round
    if round == 0:
        feat = train_graph.ndata['feat']
        pos_enc = train_graph.ndata['lap_pos_enc']
        flops, total_params = compute_flops_params(model, train_graph, feat, pos_enc)
        
    optimizer = torch.optim.Adam(model.parameters(), lr=args.lr)
    criterion = torch.nn.BCEWithLogitsLoss()
    
    for epoch in range(args.epoch_num):
        loss = train()
        val_auc, tmp_test_auc = test()
        print('---------------------------------------------------------------------------')
        print(f'For the {epoch} epoch, the train loss is {loss}, the val auc is {val_auc}, the test auc is {tmp_test_auc}.')
        if val_auc > best_val_auc:
            best_val_auc = val_auc
            test_auc = tmp_test_auc
    
    test_auc_list.append(test_auc)

# Calculate final results
auc_avg = float(np.average(test_auc_list))
auc_std = float(np.std(test_auc_list))

print('Mission completes.')
print(f'The avg auc is {auc_avg}, and the std is {auc_std}.')

# Save results section
result_str = (f"Model: {args.model}, Dataset: {args.dataset}, "
             f"Avg AUC: {auc_avg:.4f}±{auc_std:.4f},"
             f"Flops: {flops/1e6:.2f}M,"
             f"Params:{total_params:.2f}\n")

# Write results to file
with open('link_results.txt', 'a') as f:  # Use append mode
    f.write(result_str)

print("Results have been saved to link_results.txt")