#!/bin/bash

BASE_DIR=$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)
cd $BASE_DIR

export PYTHONPATH="$BASE_DIR:$PYTHONPATH"

### ZINC

#### GT

# python -m graph_regression.gt_zinc_train \
#   --batch-size 128 \
#   --epochs 300 \
#   --model GT \
#   --patience 20 \
#   --pos_enc_dim 2 \
#   --hidden_dim 64 \
#   --layers 4 \
#   --in_feat_dropout 0 \
#   --dropout 0 \
#   --train_round 1


# #### HeteGAT

# python -m graph_regression.HeteGAT_zinc_train \
#   --model HeteGAT
  
# #### HeteGAT+LPAT

# python -m graph_regression.HeteGAT_zinc_train \
#   --model HeteGAT_LPAT
  
#### HLGAT

# python -m graph_regression.HLGAT_zinc_train \
#   --model HLGAT
  
#### HLGAT+LPAT

# python -m graph_regression.HLGAT_zinc_train \
#   --model HLGAT_LPAT \
#   --hidden_dim 128 \
#   --train_round 5

#### GAT

python -m graph_regression.train_zinc \
  --model GAT
  
python -m graph_regression.train_zinc \
  --model GAT_LPAT
  
#### GATv2
  
python -m graph_regression.train_zinc \
  --model GATv2
  
python -m graph_regression.train_zinc \
  --model GATv2_LPAT
  
### GLCN

python -m graph_regression.train_zinc \
  --model GLCN
  
python -m graph_regression.train_zinc \
  --model GLCN_LPAT

### CFGAT

python -m graph_regression.train_zinc \
  --model CFGAT
  
python -m graph_regression.train_zinc \
  --model CFGAT_LPAT

#### KAAGAT

python -m graph_regression.train_zinc \
  --model KAAGAT
  
python -m graph_regression.train_zinc \
  --model KAAGAT_LPAT